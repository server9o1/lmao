import React from 'react';
import './App.css';
import { AppProvider, useApp } from './context/AppContext';

// Layout
import Sidebar from './components/Sidebar';
import TopBar from './components/TopBar';
import ToastContainer from './components/ToastContainer';
import PhoneMockup from './components/PhoneMockup';
import ConfettiOverlay from './components/ConfettiOverlay';

// Modules
import Dashboard    from './modules/Dashboard';
import OrderEntry   from './modules/OrderEntry';
import SweetPoints  from './modules/SweetPoints';
import CelebrationHub from './modules/CelebrationHub';
import MysteryBox   from './modules/MysteryBox';
import Members      from './modules/Members';
import WallOfFame   from './modules/WallOfFame';
import Financial    from './modules/Financial';
import Staff        from './modules/Staff';
import Settings     from './modules/Settings';

const MODULE_COMPONENTS = {
  dashboard:   Dashboard,
  orders:      OrderEntry,
  sweetpoints: SweetPoints,
  celebration: CelebrationHub,
  mysterybox:  MysteryBox,
  members:     Members,
  walloffame:  WallOfFame,
  financial:   Financial,
  staff:       Staff,
  settings:    Settings,
};

const MODULE_HEADERS = {
  dashboard:   { title:'Dashboard',              subtitle:'Dessert Mommy operations at a glance' },
  orders:      { title:'Order Entry',            subtitle:'Counter view — place orders and earn Sweet Points' },
  sweetpoints: { title:'Sweet Points Engine',    subtitle:'Loyalty tiers, points ledger, and redemptions' },
  celebration: { title:'Celebration Hub',        subtitle:'Private event bookings and experience management' },
  mysterybox:  { title:'Mystery Dessert Box',    subtitle:'Randomised selection with equal fairness' },
  members:     { title:'Members & CRM',          subtitle:'Full customer database and activity tracking' },
  walloffame:  { title:'Wall of Fame',           subtitle:'Community content queue and TV display' },
  financial:   { title:'Financial Dashboard',    subtitle:'Revenue, break-even analysis, and projections' },
  staff:       { title:'Staff & Shifts',         subtitle:'Team roster and attendance tracking' },
  settings:    { title:'Settings & Branch',      subtitle:'System configuration, templates, and branch network' },
};

function AppShell() {
  const { state } = useApp();
  const ActiveModule = MODULE_COMPONENTS[state.activeModule] || Dashboard;
  const header = MODULE_HEADERS[state.activeModule] || {};

  return (
    <div className="app-shell">
      <Sidebar />
      <div className="main-area">
        <TopBar />
        <div className="module-content">
          <div className="module-header">
            <h1>{header.title}</h1>
            <p>{header.subtitle}</p>
          </div>
          <ActiveModule />
        </div>
      </div>

      {/* Global overlays */}
      <ToastContainer />
      <PhoneMockup />
      <ConfettiOverlay />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppShell />
    </AppProvider>
  );
}
