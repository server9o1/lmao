import React, { createContext, useContext, useReducer, useCallback } from 'react';
import {
  INITIAL_MEMBERS, INITIAL_ORDERS, INITIAL_BOOKINGS, INITIAL_WALL_POSTS,
  INITIAL_STAFF, INITIAL_MYSTERY_HISTORY, INITIAL_ACTIVITY_FEED,
  SYSTEM_CONFIG_DEFAULTS, PARTNERS, FIXED_COSTS,
  getTierFromCumulative, calculatePoints,
} from '../mockData';

// ── Initial State ──────────────────────────────────────────────────────────
const initialState = {
  members:        JSON.parse(JSON.stringify(INITIAL_MEMBERS)),
  orders:         JSON.parse(JSON.stringify(INITIAL_ORDERS)),
  bookings:       JSON.parse(JSON.stringify(INITIAL_BOOKINGS)),
  wallPosts:      JSON.parse(JSON.stringify(INITIAL_WALL_POSTS)),
  staff:          JSON.parse(JSON.stringify(INITIAL_STAFF)),
  clockedIn:      {},
  mysteryHistory: JSON.parse(JSON.stringify(INITIAL_MYSTERY_HISTORY)),
  activityFeed:   JSON.parse(JSON.stringify(INITIAL_ACTIVITY_FEED)),
  toasts:         [],
  phoneMockup:    null,
  showConfetti:   false,
  tierUpgrade:    null,
  activeModule:   'dashboard',
  systemConfig:   JSON.parse(JSON.stringify(SYSTEM_CONFIG_DEFAULTS)),
  partners:       JSON.parse(JSON.stringify(PARTNERS)),
  fixedCosts:     JSON.parse(JSON.stringify(FIXED_COSTS)),
};

// ── Reducer ────────────────────────────────────────────────────────────────
function reducer(state, action) {
  switch (action.type) {

    case 'SET_MODULE':
      return { ...state, activeModule: action.module };

    case 'ADD_TOAST': {
      const toast = { id: Date.now() + Math.random(), ...action.toast };
      return { ...state, toasts: [...state.toasts, toast] };
    }
    case 'REMOVE_TOAST':
      return { ...state, toasts: state.toasts.filter(t => t.id !== action.id) };

    case 'SHOW_PHONE_MOCKUP':
      return { ...state, phoneMockup: action.payload };
    case 'HIDE_PHONE_MOCKUP':
      return { ...state, phoneMockup: null };

    case 'SHOW_CONFETTI':
      return { ...state, showConfetti: true, tierUpgrade: action.payload };
    case 'HIDE_CONFETTI':
      return { ...state, showConfetti: false, tierUpgrade: null };

    case 'PLACE_ORDER': {
      const { memberId, memberName, items, total, payment } = action;
      const newOrderId = 'ord' + String(state.orders.length + 1).padStart(3, '0');
      const now = new Date().toISOString();

      let updatedMembers = state.members;
      let tierUpgradeInfo = null;
      let earnedPoints = 0;

      if (memberId && memberId !== 'guest') {
        const memberIdx = state.members.findIndex(m => m.username === memberId);
        if (memberIdx !== -1) {
          const member = state.members[memberIdx];
          earnedPoints = calculatePoints(total, member.tier);
          const newCumulative = member.cumulativePoints + earnedPoints;
          const newRedeemable = member.redeemablePoints + earnedPoints;
          const newTier = getTierFromCumulative(newCumulative);
          const upgraded = newTier !== member.tier;
          if (upgraded) tierUpgradeInfo = { name: member.name, newTier };
          updatedMembers = state.members.map((m, i) =>
            i === memberIdx ? {
              ...m,
              cumulativePoints: newCumulative,
              redeemablePoints: newRedeemable,
              tier: newTier,
              totalOrders: m.totalOrders + 1,
              totalSpent: m.totalSpent + total,
              lastVisit: now.split('T')[0],
            } : m
          );
        }
      }

      const newOrder = {
        id: newOrderId, memberId, memberName,
        items: items.map(i => ({ id:i.id, name:i.name, price:i.price, qty:i.qty })),
        total, payment, points: earnedPoints, source:'core', timestamp: now,
      };

      const feedEntry = {
        id: 'af' + Date.now(), type:'order', icon:'🛒', color:'#D02779',
        message: `${memberName || 'Guest'} placed an order — BDT ${total} — ${earnedPoints} pts earned`,
        time: now,
      };

      return {
        ...state,
        members: updatedMembers,
        orders: [...state.orders, newOrder],
        activityFeed: [feedEntry, ...state.activityFeed].slice(0, 50),
        tierUpgrade: tierUpgradeInfo,
      };
    }

    case 'CREATE_BOOKING': {
      const newBooking = { id: 'bk' + Date.now(), ...action.booking, status:'pending_payment' };
      const feedEntry = {
        id:'af'+Date.now(), type:'booking', icon:'🎉', color:'#9C27B0',
        message:`New Celebration Hub booking — ${action.booking.memberName} (${action.booking.package})`,
        time: new Date().toISOString(),
      };
      return {
        ...state,
        bookings: [...state.bookings, newBooking],
        activityFeed: [feedEntry, ...state.activityFeed].slice(0,50),
      };
    }

    case 'UPDATE_BOOKING_STATUS': {
      const feedEntry = {
        id:'af'+Date.now(), type:'booking', icon:'🎉', color:'#9C27B0',
        message:`Booking ${action.id} status updated to ${action.status}`,
        time: new Date().toISOString(),
      };
      return {
        ...state,
        bookings: state.bookings.map(b => b.id === action.id ? { ...b, status:action.status } : b),
        activityFeed: [feedEntry, ...state.activityFeed].slice(0,50),
      };
    }

    case 'UPDATE_DECORATION_CHECKLIST':
      return {
        ...state,
        bookings: state.bookings.map(b =>
          b.id === action.id
            ? { ...b, decorationChecklist:{ ...b.decorationChecklist, [action.item]:action.value } }
            : b
        ),
      };

    case 'COMPLETE_BOOKING_WITH_POINTS': {
      const { bookingId, attendeeUsernames } = action;
      let updatedMembers = state.members;
      const feedEntries = [];
      attendeeUsernames.forEach(username => {
        const idx = updatedMembers.findIndex(m => m.username === username);
        if (idx !== -1) {
          const pts = 200;
          const m = updatedMembers[idx];
          const newCumulative = m.cumulativePoints + pts;
          const newTier = getTierFromCumulative(newCumulative);
          updatedMembers = updatedMembers.map((mm, i) =>
            i === idx ? { ...mm, cumulativePoints:newCumulative, redeemablePoints:mm.redeemablePoints+pts, tier:newTier } : mm
          );
          feedEntries.push({
            id:'af'+Date.now()+idx, type:'points', icon:'⭐', color:'#F9A825',
            message:`${m.name} earned 200 pts (Celebration Hub attendee bonus)`,
            time: new Date().toISOString(),
          });
        }
      });
      return {
        ...state,
        members: updatedMembers,
        bookings: state.bookings.map(b => b.id === bookingId ? { ...b, status:'completed' } : b),
        activityFeed: [...feedEntries, ...state.activityFeed].slice(0,50),
      };
    }

    case 'SPIN_MYSTERY_BOX': {
      const { memberId, memberName, selectedItem } = action;
      const price = 249;
      const memberIdx = state.members.findIndex(m => m.username === memberId);
      let updatedMembers = state.members;
      let earnedPoints = 0;
      if (memberIdx !== -1) {
        const member = state.members[memberIdx];
        earnedPoints = calculatePoints(price, member.tier);
        updatedMembers = state.members.map((m, i) =>
          i === memberIdx ? {
            ...m,
            cumulativePoints: m.cumulativePoints + earnedPoints,
            redeemablePoints: m.redeemablePoints + earnedPoints,
            totalOrders: m.totalOrders + 1,
            totalSpent: m.totalSpent + price,
          } : m
        );
      }
      const newOrder = {
        id:'ordmb'+Date.now(), memberId, memberName,
        items:[{ id:selectedItem.id, name:selectedItem.name, price, qty:1 }],
        total:price, payment:'Cash', points:earnedPoints, source:'mystery',
        timestamp: new Date().toISOString(),
      };
      const updatedHistory = state.mysteryHistory.map(h =>
        h.itemId === selectedItem.id ? { ...h, count:h.count+1 } : h
      );
      const feedEntry = {
        id:'af'+Date.now(), type:'mystery', icon:'🎁', color:'#FF5722',
        message:`${memberName} opened Mystery Box — revealed ${selectedItem.name} — ${earnedPoints} pts earned`,
        time: new Date().toISOString(),
      };
      return {
        ...state,
        members: updatedMembers,
        orders: [...state.orders, newOrder],
        mysteryHistory: updatedHistory,
        activityFeed: [feedEntry, ...state.activityFeed].slice(0,50),
      };
    }

    case 'REDEEM_POINTS': {
      const { memberId, rewardCost, rewardName } = action;
      const memberIdx = state.members.findIndex(m => m.username === memberId);
      if (memberIdx === -1) return state;
      const feedEntry = {
        id:'af'+Date.now(), type:'redemption', icon:'🎁', color:'#00897B',
        message:`${state.members[memberIdx].name} redeemed ${rewardCost} pts for ${rewardName}`,
        time: new Date().toISOString(),
      };
      return {
        ...state,
        members: state.members.map((m, i) =>
          i === memberIdx ? { ...m, redeemablePoints:m.redeemablePoints - rewardCost } : m
        ),
        activityFeed: [feedEntry, ...state.activityFeed].slice(0,50),
      };
    }

    case 'AWARD_BONUS_POINTS': {
      const { memberId, points, reason } = action;
      const memberIdx = state.members.findIndex(m => m.username === memberId);
      if (memberIdx === -1) return state;
      const member = state.members[memberIdx];
      const newCumulative = member.cumulativePoints + points;
      const newTier = getTierFromCumulative(newCumulative);
      const feedEntry = {
        id:'af'+Date.now(), type:'points', icon:'⭐', color:'#F9A825',
        message:`${member.name} awarded ${points} bonus pts — ${reason}`,
        time: new Date().toISOString(),
      };
      return {
        ...state,
        members: state.members.map((m, i) =>
          i === memberIdx ? {
            ...m, cumulativePoints:newCumulative,
            redeemablePoints:m.redeemablePoints+points, tier:newTier
          } : m
        ),
        activityFeed: [feedEntry, ...state.activityFeed].slice(0,50),
      };
    }

    case 'APPROVE_WALL_POST': {
      const post = state.wallPosts.find(p => p.id === action.id);
      if (!post) return state;
      const memberIdx = state.members.findIndex(m => m.username === post.memberId);
      let updatedMembers = state.members;
      if (memberIdx !== -1) {
        const m = state.members[memberIdx];
        const newCumulative = m.cumulativePoints + 50;
        updatedMembers = state.members.map((mm, i) =>
          i === memberIdx ? { ...mm, cumulativePoints:newCumulative, redeemablePoints:mm.redeemablePoints+50, tier:getTierFromCumulative(newCumulative) } : mm
        );
      }
      const feedEntry = {
        id:'af'+Date.now(), type:'wall', icon:'📸', color:'#FF9800',
        message:`Wall of Fame post approved — ${post.memberName} (+50 pts)`,
        time: new Date().toISOString(),
      };
      return {
        ...state,
        members: updatedMembers,
        wallPosts: state.wallPosts.map(p => p.id === action.id ? { ...p, status:'approved', points:50 } : p),
        activityFeed: [feedEntry, ...state.activityFeed].slice(0,50),
      };
    }

    case 'REJECT_WALL_POST':
      return {
        ...state,
        wallPosts: state.wallPosts.map(p =>
          p.id === action.id ? { ...p, status:'rejected', reason:action.reason || '' } : p
        ),
      };

    case 'ADD_WALL_POST': {
      const newPost = { id:'wp'+Date.now(), ...action.post, status:'pending', points:0 };
      return { ...state, wallPosts: [...state.wallPosts, newPost] };
    }

    case 'REGISTER_MEMBER': {
      const newMember = {
        username: action.username,
        name: action.name,
        phone: action.phone,
        birthdayMonth: action.birthdayMonth,
        tier: 'Bronze',
        cumulativePoints: 0,
        redeemablePoints: 0,
        totalOrders: 0,
        totalSpent: 0,
        memberSince: new Date().toISOString().split('T')[0],
        lastVisit: new Date().toISOString().split('T')[0],
      };
      const feedEntry = {
        id:'af'+Date.now(), type:'member', icon:'👤', color:'#00897B',
        message:`New member registered — ${action.name} (${action.username})`,
        time: new Date().toISOString(),
      };
      return {
        ...state,
        members: [...state.members, newMember],
        activityFeed: [feedEntry, ...state.activityFeed].slice(0,50),
      };
    }

    case 'CLOCK_IN': {
      return {
        ...state,
        staff: state.staff.map(s => s.id === action.staffId ? { ...s, clockedIn:true } : s),
        clockedIn: { ...state.clockedIn, [action.staffId]: new Date().toISOString() },
      };
    }
    case 'CLOCK_OUT':
      return {
        ...state,
        staff: state.staff.map(s => s.id === action.staffId ? { ...s, clockedIn:false } : s),
        clockedIn: Object.fromEntries(Object.entries(state.clockedIn).filter(([k]) => k !== action.staffId)),
      };

    case 'UPDATE_CONFIG':
      return { ...state, systemConfig: { ...state.systemConfig, ...action.config } };

    case 'UPDATE_FIXED_COST':
      return {
        ...state,
        fixedCosts: state.fixedCosts.map(c =>
          c.item === action.item ? { ...c, monthly:action.value } : c
        ),
      };

    case 'MARK_PARTNER_PAID':
      return {
        ...state,
        partners: state.partners.map(p => p.name === action.name ? { ...p, paidOut:true } : p),
      };

    case 'RESET_DEMO':
      return {
        ...initialState,
        members:        JSON.parse(JSON.stringify(INITIAL_MEMBERS)),
        orders:         JSON.parse(JSON.stringify(INITIAL_ORDERS)),
        bookings:       JSON.parse(JSON.stringify(INITIAL_BOOKINGS)),
        wallPosts:      JSON.parse(JSON.stringify(INITIAL_WALL_POSTS)),
        staff:          JSON.parse(JSON.stringify(INITIAL_STAFF)),
        mysteryHistory: JSON.parse(JSON.stringify(INITIAL_MYSTERY_HISTORY)),
        activityFeed:   JSON.parse(JSON.stringify(INITIAL_ACTIVITY_FEED)),
        partners:       JSON.parse(JSON.stringify(PARTNERS)),
        fixedCosts:     JSON.parse(JSON.stringify(FIXED_COSTS)),
      };

    default:
      return state;
  }
}

// ── Context ────────────────────────────────────────────────────────────────
const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  const addToast = useCallback((type, message, duration=3500) => {
    const id = Date.now() + Math.random();
    dispatch({ type:'ADD_TOAST', toast:{ id, toastType:type, message } });
    setTimeout(() => dispatch({ type:'REMOVE_TOAST', id }), duration);
  }, []);

  const showPhoneMockup = useCallback((template, memberName, extra={}) => {
    dispatch({ type:'SHOW_PHONE_MOCKUP', payload:{ template, memberName, extra } });
    setTimeout(() => dispatch({ type:'HIDE_PHONE_MOCKUP' }), 5000);
  }, []);

  const triggerConfetti = useCallback((info) => {
    dispatch({ type:'SHOW_CONFETTI', payload:info });
    setTimeout(() => dispatch({ type:'HIDE_CONFETTI' }), 3500);
  }, []);

  const placeOrder = useCallback((memberId, memberName, items, total, payment) => {
    dispatch({ type:'PLACE_ORDER', memberId, memberName, items, total, payment });
  }, []);

  return (
    <AppContext.Provider value={{ state, dispatch, addToast, showPhoneMockup, triggerConfetti, placeOrder }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
