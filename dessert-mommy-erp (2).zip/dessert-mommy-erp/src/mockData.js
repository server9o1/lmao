// ============================================================
// DESSERT MOMMY ERP — MOCK DATA (All seed data for prototype)
// ============================================================

export const TIER_CONFIG = {
  Bronze:   { name:'Bronze',   color:'#CD7F32', bg:'#FFF8F0', minPoints:0,    multiplier:1.0, benefits:['1 pt per BDT spent','Birthday 10% off','Member offers'] },
  Silver:   { name:'Silver',   color:'#757575', bg:'#F5F5F5', minPoints:500,   multiplier:1.2, benefits:['1.2× multiplier','Birthday 15% off','Early specials access'] },
  Gold:     { name:'Gold',     color:'#F9A825', bg:'#FFFDE7', minPoints:1500,  multiplier:1.5, benefits:['1.5× multiplier','Birthday 20% off','Priority booking'] },
  Platinum: { name:'Platinum', color:'#7B1FA2', bg:'#F3E5F5', minPoints:3000,  multiplier:2.0, benefits:['2× multiplier','Free birthday cake','1 free booking/yr','VIP access'] },
};

export const MENU_ITEMS = [
  { id:'mi1', name:'Choco Cloud Cup',          price:199, emoji:'🍫', color:'#4E342E' },
  { id:'mi2', name:'Strawberry Nutella Dream', price:199, emoji:'🍓', color:'#E91E63' },
  { id:'mi3', name:'The Loaded Square',        price:349, emoji:'🍰', color:'#795548' },
  { id:'mi4', name:'Pancake Slice',            price:249, emoji:'🥞', color:'#FF9800' },
  { id:'mi5', name:'Dreamy Waffle',            price:299, emoji:'🧇', color:'#F9A825' },
  { id:'mi6', name:'IceChoco Taco',            price:299, emoji:'🌮', color:'#0288D1' },
  { id:'mi7', name:'Monthly Mystery Special',  price:229, emoji:'✨', color:'#9C27B0' },
];

export const REWARDS = [
  { id:'r1', name:'Free Topping',   cost:100,  description:'Add any topping free' },
  { id:'r2', name:'10% Discount',   cost:500,  description:'10% off your next order' },
  { id:'r3', name:'Free Dessert',   cost:4000, description:'One free dessert of your choice' },
];

const today = new Date();
const pad = n => String(n).padStart(2,'0');
const todayStr = `${today.getFullYear()}-${pad(today.getMonth()+1)}-${pad(today.getDate())}`;
const lastWeek = new Date(today); lastWeek.setDate(today.getDate()-7);
const lastWeekStr = `${lastWeek.getFullYear()}-${pad(lastWeek.getMonth()+1)}-${pad(lastWeek.getDate())}`;
const nextSat = new Date(today); nextSat.setDate(today.getDate() + ((6 - today.getDay() + 7) % 7 || 7));
const nextSatStr = `${nextSat.getFullYear()}-${pad(nextSat.getMonth()+1)}-${pad(nextSat.getDate())}`;

export const INITIAL_MEMBERS = [
  { username:'DM-4A9F', name:'Arif Rahman',     tier:'Gold',     cumulativePoints:2340, redeemablePoints:890,  birthdayMonth:4,  phone:'+8801711000001', totalOrders:23, totalSpent:5840,  memberSince:'2023-06-15', lastVisit:todayStr    },
  { username:'DM-7B2C', name:'Nusrat Jahan',    tier:'Silver',   cumulativePoints:980,  redeemablePoints:480,  birthdayMonth:7,  phone:'+8801711000002', totalOrders:12, totalSpent:2490,  memberSince:'2023-09-20', lastVisit:todayStr    },
  { username:'DM-1E5D', name:'Tariq Islam',     tier:'Platinum', cumulativePoints:5120, redeemablePoints:2100, birthdayMonth:11, phone:'+8801711000003', totalOrders:67, totalSpent:18920, memberSince:'2023-01-10', lastVisit:todayStr    },
  { username:'DM-3C8A', name:'Mithila Roy',     tier:'Bronze',   cumulativePoints:210,  redeemablePoints:210,  birthdayMonth:3,  phone:'+8801711000004', totalOrders:3,  totalSpent:657,   memberSince:'2023-12-01', lastVisit:lastWeekStr },
  { username:'DM-9F4B', name:'Sabbir Ahmed',    tier:'Gold',     cumulativePoints:1750, redeemablePoints:650,  birthdayMonth:8,  phone:'+8801711000005', totalOrders:19, totalSpent:4890,  memberSince:'2023-04-22', lastVisit:todayStr    },
  { username:'DM-2D6E', name:'Priya Sen',       tier:'Silver',   cumulativePoints:1100, redeemablePoints:300,  birthdayMonth:6,  phone:'+8801711000006', totalOrders:14, totalSpent:3210,  memberSince:'2023-07-08', lastVisit:todayStr    },
  { username:'DM-5A1F', name:'Karim Uddin',     tier:'Bronze',   cumulativePoints:45,   redeemablePoints:45,   birthdayMonth:2,  phone:'+8801711000007', totalOrders:1,  totalSpent:199,   memberSince:'2024-01-02', lastVisit:lastWeekStr },
  { username:'DM-8E3C', name:'Lamiya Hassan',   tier:'Gold',     cumulativePoints:2890, redeemablePoints:1200, birthdayMonth:12, phone:'+8801711000008', totalOrders:31, totalSpent:8420,  memberSince:'2023-03-15', lastVisit:todayStr    },
  { username:'DM-6B7D', name:'Rafiq Chowdhury', tier:'Silver',   cumulativePoints:620,  redeemablePoints:420,  birthdayMonth:9,  phone:'+8801711000009', totalOrders:8,  totalSpent:1980,  memberSince:'2023-10-30', lastVisit:todayStr    },
  { username:'DM-0C9A', name:'Sadia Islam',     tier:'Platinum', cumulativePoints:4300, redeemablePoints:980,  birthdayMonth:4,  phone:'+8801711000010', totalOrders:54, totalSpent:15670, memberSince:'2023-02-28', lastVisit:todayStr    },
];

export const INITIAL_ORDERS = [
  { id:'ord001', memberId:'DM-1E5D', memberName:'Tariq Islam',     items:[{id:'mi5',name:'Dreamy Waffle',price:299,qty:1}],         total:299,  payment:'bKash',  points:598,  source:'core', timestamp:`${todayStr}T09:15:00` },
  { id:'ord002', memberId:'DM-0C9A', memberName:'Sadia Islam',     items:[{id:'mi1',name:'Choco Cloud Cup',price:199,qty:2}],       total:398,  payment:'Cash',   points:796,  source:'core', timestamp:`${todayStr}T10:30:00` },
  { id:'ord003', memberId:'DM-4A9F', memberName:'Arif Rahman',     items:[{id:'mi3',name:'The Loaded Square',price:349,qty:1},{id:'mi4',name:'Pancake Slice',price:249,qty:1}], total:598, payment:'Nagad', points:897, source:'core', timestamp:`${todayStr}T11:20:00` },
  { id:'ord004', memberId:'DM-9F4B', memberName:'Sabbir Ahmed',    items:[{id:'mi6',name:'IceChoco Taco',price:299,qty:1}],         total:299,  payment:'bKash',  points:448,  source:'core', timestamp:`${todayStr}T12:05:00` },
  { id:'ord005', memberId:'DM-8E3C', memberName:'Lamiya Hassan',   items:[{id:'mi2',name:'Strawberry Nutella Dream',price:199,qty:2}], total:398, payment:'Cash', points:597,  source:'core', timestamp:`${todayStr}T13:10:00` },
];

export const INITIAL_BOOKINGS = [
  {
    id:'bk001', memberId:'DM-4A9F', memberName:'Arif Rahman',
    package:'Grand Celebration', packagePrice:8500,
    date:nextSatStr, timeSlot:'6:00 PM', eventType:'Birthday',
    theme:'Strawberry', partySize:6, addons:[], specialNotes:'Gluten-free options needed',
    advance:4250, balance:4250, status:'confirmed', createdAt:todayStr,
    decorationChecklist:{ balloons:false, bannerHung:false, tableSet:false, lightingReady:false, photoProps:false }
  },
  {
    id:'bk002', memberId:'DM-1E5D', memberName:'Tariq Islam',
    package:'Royal Celebration', packagePrice:12000,
    date:lastWeekStr, timeSlot:'7:00 PM', eventType:'Anniversary',
    theme:'Romantic', partySize:8, addons:['Chocolate Bouquet BDT 1200'],
    specialNotes:'Surprise party setup needed',
    advance:6000, balance:0, status:'completed', createdAt:lastWeekStr,
    decorationChecklist:{ balloons:true, bannerHung:true, tableSet:true, lightingReady:true, photoProps:true }
  },
  {
    id:'bk003', memberId:'DM-3C8A', memberName:'Mithila Roy',
    package:'Sweet Celebration', packagePrice:5500,
    date:todayStr, timeSlot:'4:00 PM', eventType:'Birthday',
    theme:'Cartoon', partySize:4, addons:[], specialNotes:'',
    advance:2750, balance:2750, status:'pending_payment', createdAt:todayStr,
    decorationChecklist:{ balloons:false, bannerHung:false, tableSet:false, lightingReady:false, photoProps:false }
  },
];

export const PACKAGES = [
  { name:'Sweet Celebration',  price:5500,  color:'#E91E63', inclusions:['Decoration (Balloon + Banner)','Photo frame backdrop','Staff host (1 hour)','Dessert platter (4 pax)','Welcome mocktail'] },
  { name:'Grand Celebration',  price:8500,  color:'#D02779', inclusions:['Premium decoration','Custom backdrop','Staff host (2 hours)','Dessert platter (8 pax)','Mocktail + cake cutting'] },
  { name:'Royal Celebration',  price:12000, color:'#7B1FA2', inclusions:['Full theme decoration','Dedicated events coordinator','Custom cake','Dessert platter (12 pax)','Photography (1 hour)','Gift bag per guest'] },
];

export const INITIAL_WALL_POSTS = [
  { id:'wp001', platform:'Instagram', memberId:'DM-4A9F', memberName:'Arif Rahman',    url:'https://instagram.com/p/abc123', date:todayStr,    status:'pending',  points:0   },
  { id:'wp002', platform:'Facebook',  memberId:'DM-9F4B', memberName:'Sabbir Ahmed',   url:'https://facebook.com/p/xyz789', date:todayStr,    status:'pending',  points:0   },
  { id:'wp003', platform:'TikTok',    memberId:'DM-2D6E', memberName:'Priya Sen',      url:'https://tiktok.com/@user/abc',  date:todayStr,    status:'pending',  points:0   },
  { id:'wp004', platform:'Instagram', memberId:'DM-8E3C', memberName:'Lamiya Hassan',  url:'https://instagram.com/p/lmn456', date:lastWeekStr, status:'approved', points:50  },
  { id:'wp005', platform:'Facebook',  memberId:'DM-0C9A', memberName:'Sadia Islam',    url:'https://facebook.com/p/def101', date:lastWeekStr, status:'approved', points:50  },
  { id:'wp006', platform:'Instagram', memberId:'DM-1E5D', memberName:'Tariq Islam',    url:'https://instagram.com/p/ghi202', date:lastWeekStr, status:'approved', points:50  },
  { id:'wp007', platform:'TikTok',    memberId:'DM-6B7D', memberName:'Rafiq Chowdhury',url:'https://tiktok.com/@user/jkl', date:lastWeekStr, status:'approved', points:50  },
  { id:'wp008', platform:'Facebook',  memberId:'DM-5A1F', memberName:'Karim Uddin',    url:'https://facebook.com/p/mno303', date:lastWeekStr, status:'rejected', points:0, reason:'Post did not tag #DessertMommy' },
];

export const INITIAL_STAFF = [
  { id:'st001', name:'Sazidur Rahman',         role:'Founder & GM',                  type:'Full-time',  wage:null,  hoursThisMonth:168, clockedIn:false },
  { id:'st002', name:'Bristy Naidu',           role:'Marketing & Sweet Points Mgr',  type:'Full-time',  wage:null,  hoursThisMonth:160, clockedIn:false },
  { id:'st003', name:'Ferdousi Hussain Promi', role:'Operations Manager',             type:'Full-time',  wage:null,  hoursThisMonth:164, clockedIn:false },
  { id:'st004', name:'Ramisa Rawnak',          role:'Finance Manager',               type:'Full-time',  wage:null,  hoursThisMonth:162, clockedIn:false },
  { id:'st005', name:'Tahiya Jannat',          role:'Customer Experience Manager',   type:'Full-time',  wage:null,  hoursThisMonth:160, clockedIn:false },
  { id:'st006', name:'Mahbub Alam',            role:'Head Dessert Chef',             type:'Full-time',  wage:16000, hoursThisMonth:176, clockedIn:false },
  { id:'st007', name:'Rashida Khanam',         role:'Service Staff',                 type:'Full-time',  wage:8500,  hoursThisMonth:160, clockedIn:false },
  { id:'st008', name:'Nabila Chowdhury',       role:'Celebration Hub Events Staff',  type:'Part-time',  wage:6000,  hoursThisMonth:80,  clockedIn:false },
  { id:'st009', name:'Farhan Hossain',         role:'Social Media Manager',          type:'Part-time',  wage:7000,  hoursThisMonth:64,  clockedIn:false },
];

export const PARTNERS = [
  { name:'Sajid',  monthlyDrawing:6000, paidOut:false },
  { name:'Bristy', monthlyDrawing:6000, paidOut:false },
  { name:'Promi',  monthlyDrawing:6000, paidOut:false },
  { name:'Ramisa', monthlyDrawing:6000, paidOut:false },
  { name:'Tahiya', monthlyDrawing:6000, paidOut:false },
];

export const INITIAL_MYSTERY_HISTORY = [
  { itemId:'mi1', itemName:'Choco Cloud Cup',          count:8  },
  { itemId:'mi2', itemName:'Strawberry Nutella Dream', count:6  },
  { itemId:'mi3', itemName:'The Loaded Square',        count:5  },
  { itemId:'mi4', itemName:'Pancake Slice',            count:7  },
  { itemId:'mi5', itemName:'Dreamy Waffle',            count:9  },
  { itemId:'mi6', itemName:'IceChoco Taco',            count:6  },
  { itemId:'mi7', itemName:'Monthly Mystery Special',  count:7  },
];

// 7-day revenue by stream (today is day 7, partial)
export const HISTORICAL_REVENUE = (() => {
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(today); d.setDate(today.getDate() - i);
    const dayLabel = d.toLocaleDateString('en-US', { weekday:'short' });
    if (i === 0) {
      // today — partial (pre-loaded orders only)
      days.push({ day:dayLabel, core:1992, celebration:0, mystery:0 });
    } else {
      days.push({
        day: dayLabel,
        core: 3000 + Math.floor(Math.random()*3000),
        celebration: [0,0,8500,0,12000,0,0][6-i] || 0,
        mystery: 229 * (2 + Math.floor(Math.random()*5)),
      });
    }
  }
  return days;
})();

export const WHATSAPP_TEMPLATES = [
  { id:'wt01', name:'Welcome — New Member',      category:'Onboarding',    body:'🎉 Welcome to Dessert Mommy, {{name}}! Your member ID is *{{username}}*. Your journey to sweetness starts now! 🍫 Visit us at Kumarpara, Sylhet. Use your ID at every order to earn Sweet Points.' },
  { id:'wt02', name:'Order Confirmation',        category:'Transactional', body:'✅ Order confirmed! Hi {{name}}, your order of *BDT {{amount}}* has been received. You earned *{{points}} Sweet Points*. New balance: *{{balance}} pts*. Thank you! — Dessert Mommy 🍓' },
  { id:'wt03', name:'Tier Upgrade — Silver',     category:'Loyalty',       body:'🥈 Congratulations {{name}}! You\'ve reached *SILVER* tier! Your multiplier is now 1.2×. Enjoy exclusive Silver member benefits at Dessert Mommy! 🎊' },
  { id:'wt04', name:'Tier Upgrade — Gold',       category:'Loyalty',       body:'🥇 WOW {{name}}! You\'ve unlocked *GOLD* tier! Enjoy 1.5× points on every visit, priority Celebration Hub booking, and more! You\'re a Dessert Mommy VIP! 💛' },
  { id:'wt05', name:'Tier Upgrade — Platinum',   category:'Loyalty',       body:'💎 Incredible, {{name}}! You are now *PLATINUM* — our highest tier! Enjoy 2× points, a FREE birthday cake, 1 complimentary Celebration Hub booking per year, and VIP access to all events! 🌟' },
  { id:'wt06', name:'Birthday Greeting',         category:'Loyalty',       body:'🎂 Happy Birthday, {{name}}! 🎉 On behalf of everyone at Dessert Mommy, we wish you the sweetest day! Show this message at our counter for your *exclusive birthday discount*. We can\'t wait to celebrate with you! 🎊' },
  { id:'wt07', name:'Booking Confirmed',         category:'Celebration',   body:'🎉 Your Dessert Mommy celebration is confirmed!\n\n📅 Date: *{{date}}*\n🕐 Time: *{{time}}*\n📦 Package: *{{package}}*\n🎨 Theme: *{{theme}}*\n👥 Guests: *{{guests}}*\n\nAdvance paid: BDT {{advance}}. Balance (BDT {{balance}}) due on event day. We\'re so excited to celebrate with you! 💕' },
  { id:'wt08', name:'Day-Of Staff Alert',        category:'Operations',    body:'⚠️ TODAY\'S CELEBRATION ALERT ⚠️\n\n🎉 Event: {{package}}\n👤 Customer: {{name}}\n📅 Date: TODAY at {{time}}\n🎨 Theme: {{theme}}\n👥 Guests: {{guests}}\n\nChecklist:\n☐ Balloons inflated\n☐ Banner hung\n☐ Table set\n☐ Lighting ready\n☐ Photo props placed\n\nPlease ensure setup is complete 1 hour before event. — DM Management' },
  { id:'wt09', name:'Wall of Fame Approved',     category:'Community',     body:'🌟 Congratulations {{name}}! Your post has been featured on our *Wall of Fame*! You\'ve earned *50 Sweet Points* as a thank you. You\'re now part of the Dessert Mommy family showcase! Keep sharing your moments with #DessertMommy 💕' },
  { id:'wt10', name:'Points Redemption',         category:'Transactional', body:'✅ Points redeemed! Hi {{name}}, you\'ve used *{{points}} Sweet Points* for *{{reward}}*. Remaining balance: *{{balance}} pts*. Visit us soon! — Dessert Mommy' },
  { id:'wt11', name:'Mystery Box Reveal',        category:'Transactional', body:'🎁 Your Mystery Dessert Box is ready! Hi {{name}}, today\'s mystery selection is being prepared with love. Come collect your surprise! BDT 249. Enjoy! 🍫 — Dessert Mommy' },
  { id:'wt12', name:'Booking Reminder',          category:'Celebration',   body:'🌸 Reminder! Your Dessert Mommy celebration is *tomorrow* ({{date}}) at *{{time}}*. Package: {{package}}. Balance due: *BDT {{balance}}*. We can\'t wait to make it magical! — Dessert Mommy 💕' },
];

export const INITIAL_ACTIVITY_FEED = [
  { id:'af001', type:'order',    icon:'🛒', color:'#D02779', message:'Tariq Islam placed an order — BDT 299 — 598 pts earned',              time: new Date(today.getTime()-4*3600000).toISOString() },
  { id:'af002', type:'order',    icon:'🛒', color:'#D02779', message:'Sadia Islam placed an order — BDT 398 — 796 pts earned',              time: new Date(today.getTime()-3*3600000).toISOString() },
  { id:'af003', type:'order',    icon:'🛒', color:'#D02779', message:'Arif Rahman placed an order — BDT 598 — 897 pts earned',              time: new Date(today.getTime()-2.5*3600000).toISOString() },
  { id:'af004', type:'booking',  icon:'🎉', color:'#9C27B0', message:'New Celebration Hub booking confirmed — Arif Rahman (Grand, Apr 18)', time: new Date(today.getTime()-2*3600000).toISOString() },
  { id:'af005', type:'order',    icon:'🛒', color:'#D02779', message:'Sabbir Ahmed placed an order — BDT 299 — 448 pts earned',             time: new Date(today.getTime()-1.5*3600000).toISOString() },
  { id:'af006', type:'order',    icon:'🛒', color:'#D02779', message:'Lamiya Hassan placed an order — BDT 398 — 597 pts earned',            time: new Date(today.getTime()-1*3600000).toISOString() },
  { id:'af007', type:'wall',     icon:'📸', color:'#FF9800', message:'New Wall of Fame post submitted — Arif Rahman (Instagram)',           time: new Date(today.getTime()-0.5*3600000).toISOString() },
];

export const SYSTEM_CONFIG_DEFAULTS = {
  breakEvenOrders: 22,
  fixedMonthlyCosts: 109167,
  variableCostPercent: 38,
  avgSellingPrice: 267,
  earnRates: { Bronze:1.0, Silver:1.2, Gold:1.5, Platinum:2.0 },
};

export const PROJECTION_DATA = [
  { period:'Y1 Q1', revenue:288000,  profit:-150000 },
  { period:'Y1 Q2', revenue:360000,  profit:-110000 },
  { period:'Y1 Q3', revenue:432000,  profit:-60000  },
  { period:'Y1 Q4', revenue:456300,  profit:-37494  },
  { period:'Y2 Q1', revenue:680000,  profit:100000  },
  { period:'Y2 Q2', revenue:760000,  profit:150000  },
  { period:'Y2 Q3', revenue:840000,  profit:185000  },
  { period:'Y2 Q4', revenue:880050,  profit:214230  },
  { period:'Y3 Q1', revenue:1100000, profit:370000  },
  { period:'Y3 Q2', revenue:1150000, profit:400000  },
  { period:'Y3 Q3', revenue:1220000, profit:430000  },
  { period:'Y3 Q4', revenue:1296475, profit:445214  },
];

export const FIXED_COSTS = [
  { item:'Rent (Kumarpara)',    monthly:15000, editable:true  },
  { item:'Staff — Chef',        monthly:16000, editable:true  },
  { item:'Staff — Service',     monthly:8500,  editable:true  },
  { item:'Staff — Events',      monthly:6000,  editable:true  },
  { item:'Staff — Social Media',monthly:7000,  editable:true  },
  { item:'Utilities',           monthly:8000,  editable:true  },
  { item:'Packaging',           monthly:5000,  editable:true  },
  { item:'Marketing',           monthly:5000,  editable:true  },
  { item:'Maintenance & Misc',  monthly:3000,  editable:true  },
  { item:'Partner Drawings ×5', monthly:30000, editable:false },
  { item:'ERP / Software',      monthly:1667,  editable:false },
  { item:'Insurance & Legal',   monthly:4000,  editable:false },
];

export const MOOD_FIXER_LETTERS = {
  morning: "We know mornings can be rough. This one's just for you.\n\nYou've got this. The day is young and so is every possibility in it. Enjoy every bite.",
  afternoon: "Whatever your day has been so far — you deserve this.\n\nTake a breath. Slow down for a moment. This is your pause, your treat, your reset. You've earned it.",
  evening: "No explanation needed. You just deserve it.\n\nThe day is done. Whatever happened out there, this moment is yours. Savour it completely.",
};

export function getTierFromCumulative(points) {
  if (points >= 3000) return 'Platinum';
  if (points >= 1500) return 'Gold';
  if (points >= 500)  return 'Silver';
  return 'Bronze';
}

export function calculatePoints(orderTotal, tier) {
  return Math.floor(orderTotal * TIER_CONFIG[tier].multiplier);
}

export function formatCurrency(amount) {
  return `BDT ${amount.toLocaleString('en-BD')}`;
}

export function formatTime(isoStr) {
  const d = new Date(isoStr);
  return d.toLocaleTimeString('en-US', { hour:'2-digit', minute:'2-digit' });
}

export function formatDate(isoStr) {
  const d = new Date(isoStr);
  return d.toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' });
}

export function generateUsername() {
  const chars = '0123456789ABCDEF';
  let result = 'DM-';
  for (let i = 0; i < 4; i++) result += chars[Math.floor(Math.random() * chars.length)];
  return result;
}

export function getTimeOfDay() {
  const h = new Date().getHours();
  if (h < 12) return 'morning';
  if (h < 17) return 'afternoon';
  return 'evening';
}
