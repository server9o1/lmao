import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { formatCurrency } from '../mockData';

function useTimer(startTime) {
  const [elapsed, setElapsed] = useState(0);
  useEffect(() => {
    if (!startTime) return;
    const t = setInterval(() => {
      setElapsed(Math.floor((Date.now() - new Date(startTime).getTime()) / 1000));
    }, 1000);
    return () => clearInterval(t);
  }, [startTime]);
  return elapsed;
}

function formatElapsed(secs) {
  const h = Math.floor(secs / 3600), m = Math.floor((secs % 3600) / 60), s = secs % 60;
  return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
}

function StaffRow({ staff }) {
  const { state, dispatch, addToast } = useApp();
  const clockInTime = state.clockedIn[staff.id];
  const elapsed = useTimer(clockInTime);

  return (
    <tr>
      <td style={{fontWeight:600}}>{staff.name}</td>
      <td style={{color:'var(--text-muted)',fontSize:13}}>{staff.role}</td>
      <td>
        <span className={`badge ${staff.type==='Full-time'?'badge-info':'badge-warning'}`}>
          {staff.type}
        </span>
      </td>
      <td style={{fontWeight:600,color:'var(--teal)'}}>
        {staff.wage ? formatCurrency(staff.wage) : '(Partner)'}
      </td>
      <td style={{fontSize:13}}>{staff.hoursThisMonth}h</td>
      <td>
        {clockInTime ? (
          <div style={{display:'flex',alignItems:'center',gap:8}}>
            <span style={{
              fontFamily:'monospace',fontSize:13,fontWeight:700,
              color:'var(--teal)',background:'var(--teal-light)',
              borderRadius:6,padding:'2px 8px'
            }}>
              ⏱ {formatElapsed(elapsed)}
            </span>
            <button
              className="btn btn-sm btn-danger"
              onClick={() => { dispatch({ type:'CLOCK_OUT', staffId:staff.id }); addToast('info',`${staff.name} clocked out.`); }}
            >
              Clock Out
            </button>
          </div>
        ) : (
          <button
            className="btn btn-sm btn-success"
            onClick={() => { dispatch({ type:'CLOCK_IN', staffId:staff.id }); addToast('success',`${staff.name} clocked in.`); }}
          >
            Clock In
          </button>
        )}
      </td>
    </tr>
  );
}

export default function Staff() {
  const { state } = useApp();
  const totalMonthlyWage = state.staff.filter(s=>s.wage).reduce((sum,s)=>sum+s.wage,0);

  return (
    <div>
      {/* Today's Shift Status */}
      <div className="grid-4" style={{marginBottom:16}}>
        <div className="kpi-card">
          <div className="kpi-icon">👷</div>
          <div className="kpi-label">Total Staff</div>
          <div className="kpi-value">{state.staff.length}</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon">✅</div>
          <div className="kpi-label">Clocked In</div>
          <div className="kpi-value" style={{color:'var(--teal)'}}>{Object.keys(state.clockedIn).length}</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon">💰</div>
          <div className="kpi-label">Monthly Payroll</div>
          <div className="kpi-value">{formatCurrency(totalMonthlyWage)}</div>
          <div className="kpi-sub">Hired staff only</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon">📅</div>
          <div className="kpi-label">Annual Payroll</div>
          <div className="kpi-value">{formatCurrency(totalMonthlyWage*12)}</div>
        </div>
      </div>

      {/* Staff Roster with Clock In/Out */}
      <div className="card mb-4">
        <div className="card-header">
          <div className="card-title">Staff Roster & Attendance — Today</div>
          <div style={{fontSize:13,color:'var(--text-muted)'}}>
            {new Date().toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'})}
          </div>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Name</th><th>Role</th><th>Type</th>
                <th>Monthly Wage</th><th>Hours (This Month)</th><th>Shift</th>
              </tr>
            </thead>
            <tbody>
              {state.staff.map(s => <StaffRow key={s.id} staff={s} />)}
            </tbody>
          </table>
        </div>
      </div>

      {/* Monthly Summary */}
      <div className="card">
        <div className="card-title mb-3">Monthly Payroll Summary</div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Name</th><th>Role</th><th>Hours</th><th>Fixed Wage</th><th>Status</th></tr>
            </thead>
            <tbody>
              {state.staff.map(s => (
                <tr key={s.id}>
                  <td style={{fontWeight:600}}>{s.name}</td>
                  <td style={{color:'var(--text-muted)',fontSize:13}}>{s.role}</td>
                  <td>{s.hoursThisMonth}h</td>
                  <td style={{fontWeight:600}}>
                    {s.wage ? formatCurrency(s.wage) : <span className="badge badge-pink">Partner</span>}
                  </td>
                  <td>
                    {s.wage
                      ? <span className="badge badge-success">Payable</span>
                      : <span className="badge badge-info">Drawing BDT 6,000</span>
                    }
                  </td>
                </tr>
              ))}
              <tr style={{background:'var(--pink-light)'}}>
                <td colSpan={3} style={{fontWeight:700,padding:'10px 14px'}}>Total Monthly Payroll</td>
                <td style={{fontWeight:800,color:'var(--pink)'}}>{formatCurrency(totalMonthlyWage)}</td>
                <td />
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
