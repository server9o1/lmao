import React from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  PieChart, Pie, Cell, ResponsiveContainer,
} from 'recharts';
import { useApp } from '../context/AppContext';
import { formatCurrency } from '../mockData';

export default function Dashboard() {
  const { state } = useApp();
  const today = new Date().toISOString().split('T')[0];

  const todayOrders = state.orders.filter(o => o.timestamp.startsWith(today));
  const todayRevenue = todayOrders.reduce((s, o) => s + o.total, 0);
  // eslint-disable-next-line no-unused-vars
  const monthlyRevenue = state.orders.reduce((s, o) => s + o.total, 0)
    + state.bookings.filter(b => b.status === 'completed').reduce((s,b) => s + b.packagePrice, 0);

  const coreRev     = todayOrders.filter(o => o.source==='core').reduce((s,o)=>s+o.total,0);
  const celebRev    = state.bookings.filter(b=>b.status==='completed').reduce((s,b)=>s+b.packagePrice,0);
  const mysteryRev  = todayOrders.filter(o=>o.source==='mystery').reduce((s,o)=>s+o.total,0);

  const revenueBreakdown = [
    { name:'Core Menu',       value:coreRev    || 0, color:'#D02779' },
    { name:'Celebration Hub', value:celebRev   || 0, color:'#00897B' },
    { name:'Mystery Box',     value:mysteryRev || 0, color:'#9C27B0' },
  ].filter(d => d.value > 0);

  const target   = state.systemConfig.breakEvenOrders;
  const pct      = Math.min(100, (todayOrders.length / target) * 100);
  const rate     = todayOrders.length; // orders so far today
  const hour     = new Date().getHours() + new Date().getMinutes()/60;
  const remaining= target - todayOrders.length;
  const hoursLeft= 22 - hour; // assume 12pm-10pm window
  const willHit  = remaining <= 0 || (hoursLeft > 0 && (rate / hour) * 22 >= target);

  const upcomingBookings = state.bookings
    .filter(b => b.status === 'confirmed' && b.date >= today)
    .sort((a,b) => a.date.localeCompare(b.date))
    .slice(0,3);

  const tierDistribution = ['Bronze','Silver','Gold','Platinum'].map(t => ({
    tier: t,
    count: state.members.filter(m => m.tier === t).length,
  }));

  return (
    <div>
      {/* KPI row */}
      <div className="kpi-grid">
        <div className="kpi-card">
          <div className="kpi-icon">💰</div>
          <div className="kpi-label">Today's Revenue</div>
          <div className="kpi-value" style={{color:'var(--pink)'}}>{formatCurrency(todayRevenue)}</div>
          <div className="kpi-sub">{todayOrders.length} orders today</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon">🛒</div>
          <div className="kpi-label">Today's Orders</div>
          <div className="kpi-value">{todayOrders.length}</div>
          <div style={{marginTop:6}}>
            <div className="progress-track">
              <div className="progress-fill progress-pink" style={{width:`${pct}%`}} />
            </div>
            <div className="text-sm text-muted mt-1">{target - todayOrders.length} more to break-even</div>
          </div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon">👥</div>
          <div className="kpi-label">Active Members</div>
          <div className="kpi-value">{state.members.length}</div>
          <div className="kpi-sub">
            {state.members.filter(m=>m.tier==='Platinum').length} Platinum ·{' '}
            {state.members.filter(m=>m.tier==='Gold').length} Gold
          </div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon">🎉</div>
          <div className="kpi-label">Hub Bookings</div>
          <div className="kpi-value">{state.bookings.filter(b=>b.status!=='completed').length}</div>
          <div className="kpi-sub">This month</div>
        </div>
      </div>

      {/* Break-Even Meter */}
      <div className="breakeven-meter">
        <div className="card-header">
          <div>
            <div className="card-title" style={{fontSize:16}}>📈 Daily Break-Even Tracker</div>
            <div className="card-subtitle">Target: {target} orders/day • Avg BDT {state.systemConfig.avgSellingPrice}/order</div>
          </div>
          <div style={{
            background: willHit ? 'var(--teal-light)' : 'var(--pink-light)',
            color: willHit ? 'var(--teal-dark)' : 'var(--pink-dark)',
            borderRadius:8, padding:'6px 14px', fontSize:13, fontWeight:700
          }}>
            {todayOrders.length >= target ? '✅ Target Hit!' : willHit ? '🟢 On Track' : '🔴 Behind'}
          </div>
        </div>
        <div className="breakeven-labels">
          <span>0 orders</span>
          <span style={{color:'var(--pink)',fontWeight:700}}>{todayOrders.length} orders now</span>
          <span>{target} orders (break-even)</span>
        </div>
        <div className="breakeven-meter-track">
          <div className="breakeven-meter-fill" style={{width:`${pct}%`}} />
        </div>
        <div className="breakeven-msg">
          {todayOrders.length >= target
            ? `🎉 Break-even reached! Every additional order is pure profit.`
            : willHit
            ? `At current pace, you will hit today's break-even before closing.`
            : `${remaining} more orders needed. Current pace: ${rate} orders in ${Math.round(hour)} hrs.`
          }
        </div>
      </div>

      {/* Charts + Feed row */}
      <div className="grid-2" style={{gap:16}}>
        {/* Revenue breakdown */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">Revenue Breakdown — Today</div>
          </div>
          {revenueBreakdown.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={revenueBreakdown}
                  cx="50%" cy="50%"
                  innerRadius={55} outerRadius={85}
                  dataKey="value"
                  label={({name, value}) => `${name}: ${formatCurrency(value)}`}
                  labelLine={false}
                >
                  {revenueBreakdown.map((e,i) => (
                    <Cell key={i} fill={e.color} />
                  ))}
                </Pie>
                <Tooltip formatter={v => formatCurrency(v)} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="empty-state">
              <div className="icon">📊</div>
              <p>No revenue data yet. Place an order to see live data.</p>
            </div>
          )}
          <div style={{display:'flex',gap:12,justifyContent:'center',marginTop:8}}>
            {[{c:'#D02779',n:'Core'},{c:'#00897B',n:'Hub'},{c:'#9C27B0',n:'Mystery'}].map(l=>(
              <div key={l.n} style={{display:'flex',alignItems:'center',gap:4,fontSize:12}}>
                <div style={{width:10,height:10,borderRadius:'50%',background:l.c}}/>
                {l.n}
              </div>
            ))}
          </div>
        </div>

        {/* Activity feed */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">Live Activity Feed</div>
            <span className="badge badge-success">● Live</span>
          </div>
          <div className="activity-feed" style={{maxHeight:220,overflowY:'auto'}}>
            {state.activityFeed.slice(0,10).map(evt => (
              <div key={evt.id} className="activity-item">
                <div className="activity-dot" style={{background:`${evt.color}20`}}>
                  {evt.icon}
                </div>
                <div>
                  <div className="activity-text">{evt.message}</div>
                  <div className="activity-time">
                    {new Date(evt.time).toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'})}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tier distribution + Upcoming */}
      <div className="grid-2" style={{gap:16,marginTop:16}}>
        <div className="card">
          <div className="card-header">
            <div className="card-title">Member Tier Distribution</div>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={tierDistribution} margin={{top:0,right:0,left:-20,bottom:0}}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="tier" tick={{fontSize:12}} />
              <YAxis tick={{fontSize:12}} />
              <Tooltip />
              <Bar dataKey="count" fill="var(--pink)" radius={[6,6,0,0]}>
                {tierDistribution.map((e,i) => {
                  const colors=['#CD7F32','#757575','#F9A825','#7B1FA2'];
                  return <Cell key={i} fill={colors[i]} />;
                })}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <div className="card-header">
            <div className="card-title">Upcoming Celebrations</div>
          </div>
          {upcomingBookings.length > 0 ? (
            <div style={{display:'flex',flexDirection:'column',gap:10}}>
              {upcomingBookings.map(b => {
                const daysUntil = Math.ceil((new Date(b.date) - new Date()) / 86400000);
                return (
                  <div key={b.id} style={{
                    display:'flex',alignItems:'center',gap:12,
                    padding:12,background:'var(--bg)',borderRadius:10
                  }}>
                    <div style={{
                      width:42,height:42,background:'var(--pink-light)',
                      borderRadius:10,display:'flex',alignItems:'center',
                      justifyContent:'center',fontSize:18,flexShrink:0
                    }}>🎉</div>
                    <div style={{flex:1}}>
                      <div style={{fontWeight:600,fontSize:14}}>{b.memberName}</div>
                      <div style={{fontSize:12,color:'var(--text-muted)'}}>
                        {b.package} · {b.date}
                      </div>
                    </div>
                    <div style={{
                      background: daysUntil <= 1 ? 'var(--pink-light)' : 'var(--teal-light)',
                      color: daysUntil <= 1 ? 'var(--pink)' : 'var(--teal)',
                      borderRadius:8,padding:'4px 10px',fontSize:12,fontWeight:700
                    }}>
                      {daysUntil === 0 ? 'TODAY' : daysUntil === 1 ? 'Tomorrow' : `${daysUntil} days`}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="empty-state">
              <div className="icon">📅</div>
              <p>No upcoming bookings</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
