import React from 'react';
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer, ReferenceLine,
} from 'recharts';
import { useApp } from '../context/AppContext';
import { HISTORICAL_REVENUE, PROJECTION_DATA, formatCurrency } from '../mockData';

export default function Financial() {
  const { state, dispatch, addToast } = useApp();
  const { systemConfig, fixedCosts, partners } = state;

  const today = new Date().toISOString().split('T')[0];
  const todayOrders = state.orders.filter(o => o.timestamp.startsWith(today));
  const todayRevenue = todayOrders.reduce((s,o) => s+o.total, 0);
  const celebRevCompleted = state.bookings.filter(b=>b.status==='completed').reduce((s,b)=>s+b.packagePrice,0);
  const monthlyRevenue = state.orders.reduce((s,o)=>s+o.total,0) + celebRevCompleted;
  const ytdRevenue = monthlyRevenue * 4; // simple estimate

  const monthlyBreakEven = 176076;
  const pctToBreakEven = Math.min(100,(monthlyRevenue/monthlyBreakEven)*100);

  // Break-even calculation (live from config)
  const avgPrice   = systemConfig.avgSellingPrice;
  const varCostPct = systemConfig.variableCostPercent / 100;
  const varCost    = Math.round(avgPrice * varCostPct);
  const contribution = avgPrice - varCost;
  const annualFixed  = systemConfig.fixedMonthlyCosts * 12;
  const breakEvenOrders = Math.ceil(annualFixed / contribution);
  const breakEvenPerDay = Math.ceil(breakEvenOrders / 365);

  // Revenue stream data (HISTORICAL + today)
  const chartData = HISTORICAL_REVENUE.map((d,i) => ({
    ...d,
    ...(i === HISTORICAL_REVENUE.length-1 ? { core:todayRevenue, celebration:celebRevCompleted } : {})
  }));

  // Total monthly fixed cost from cost table
  const totalFixedMonthly = fixedCosts.reduce((s,c) => s+c.monthly, 0);
  const netMonthly = monthlyRevenue - totalFixedMonthly - (monthlyRevenue * varCostPct);
  const perPartnerExtra = Math.max(0, (netMonthly / 5) - 6000);

  function updateCost(item, val) {
    dispatch({ type:'UPDATE_FIXED_COST', item, value:parseInt(val)||0 });
  }

  function markPartnerPaid(name) {
    dispatch({ type:'MARK_PARTNER_PAID', name });
    addToast('success', `${name}'s distribution marked as paid.`);
  }

  return (
    <div>
      {/* KPI Row */}
      <div className="kpi-grid" style={{marginBottom:16}}>
        <div className="kpi-card">
          <div className="kpi-icon">💰</div>
          <div className="kpi-label">Today's Revenue</div>
          <div className="kpi-value" style={{color:'var(--pink)'}}>{formatCurrency(todayRevenue)}</div>
          <div className="kpi-sub">{todayOrders.length} orders</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon">📅</div>
          <div className="kpi-label">This Month's Revenue</div>
          <div className="kpi-value">{formatCurrency(monthlyRevenue)}</div>
          <div style={{marginTop:6}}>
            <div className="progress-track">
              <div className="progress-fill progress-pink" style={{width:`${pctToBreakEven}%`}}/>
            </div>
            <div className="text-sm text-muted mt-1">{pctToBreakEven.toFixed(0)}% of monthly break-even</div>
          </div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon">🎯</div>
          <div className="kpi-label">Monthly Break-Even</div>
          <div className="kpi-value">{formatCurrency(monthlyBreakEven)}</div>
          <div className="kpi-sub">= {breakEvenPerDay} orders/day</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-icon">📈</div>
          <div className="kpi-label">Year-to-Date (est.)</div>
          <div className="kpi-value">{formatCurrency(ytdRevenue)}</div>
          <div className="kpi-sub">Year 1 (projected loss)</div>
        </div>
      </div>

      {/* Revenue Stream Chart */}
      <div className="card mb-4">
        <div className="card-header">
          <div className="card-title">Revenue Streams — Last 7 Days</div>
          <div style={{display:'flex',gap:12,fontSize:12}}>
            {[['var(--pink)','Core Menu'],['var(--teal)','Celebration Hub'],['#9C27B0','Mystery Box']].map(([c,n])=>(
              <div key={n} style={{display:'flex',alignItems:'center',gap:4}}>
                <div style={{width:10,height:10,borderRadius:2,background:c}}/>
                {n}
              </div>
            ))}
          </div>
        </div>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={chartData} margin={{top:0,right:20,left:0,bottom:0}}>
            <CartesianGrid strokeDasharray="3 3" vertical={false}/>
            <XAxis dataKey="day" tick={{fontSize:12}}/>
            <YAxis tick={{fontSize:12}} tickFormatter={v=>`৳${(v/1000).toFixed(0)}k`}/>
            <Tooltip formatter={v=>formatCurrency(v)}/>
            <Bar dataKey="core"        fill="var(--pink)"  name="Core Menu"        radius={[4,4,0,0]} stackId="a"/>
            <Bar dataKey="celebration" fill="var(--teal)"  name="Celebration Hub"  radius={[4,4,0,0]} stackId="a"/>
            <Bar dataKey="mystery"     fill="#9C27B0"      name="Mystery Box"      radius={[4,4,0,0]} stackId="a"/>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* 3-Year Projection */}
      <div className="card mb-4">
        <div className="card-header">
          <div className="card-title">3-Year Revenue & Profit Projection</div>
          <span className="badge badge-info">Quarterly</span>
        </div>
        <ResponsiveContainer width="100%" height={260}>
          <LineChart data={PROJECTION_DATA} margin={{top:10,right:20,left:0,bottom:0}}>
            <CartesianGrid strokeDasharray="3 3" vertical={false}/>
            <XAxis dataKey="period" tick={{fontSize:11}} interval={1}/>
            <YAxis tick={{fontSize:11}} tickFormatter={v=>`৳${(v/100000).toFixed(0)}L`}/>
            <Tooltip formatter={v=>formatCurrency(v)}/>
            <ReferenceLine y={0} stroke="#ccc" strokeDasharray="3"/>
            <ReferenceLine x="Y1 Q4" stroke="var(--pink)" strokeDasharray="4" label={{value:'TODAY',position:'top',fill:'var(--pink)',fontSize:11}}/>
            <Legend/>
            <Line type="monotone" dataKey="revenue" stroke="var(--pink)" strokeWidth={3} dot={{r:4}} name="Revenue"/>
            <Line type="monotone" dataKey="profit"  stroke="var(--teal)" strokeWidth={3} dot={{r:4}} name="Net Profit"/>
          </LineChart>
        </ResponsiveContainer>
        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10,marginTop:12}}>
          {[
            {yr:'Year 1',rev:'15,36,300',profit:'-3,57,494',profitColor:'#ef5350'},
            {yr:'Year 2',rev:'31,60,050',profit:'+6,49,230',profitColor:'var(--teal)'},
            {yr:'Year 3',rev:'47,66,475',profit:'+16,45,214',profitColor:'var(--teal)'},
          ].map(y => (
            <div key={y.yr} style={{background:'var(--bg)',borderRadius:10,padding:12,textAlign:'center'}}>
              <div style={{fontSize:11,color:'var(--text-muted)',fontWeight:700,textTransform:'uppercase'}}>{y.yr}</div>
              <div style={{fontSize:16,fontWeight:800,margin:'4px 0'}}>৳{y.rev}</div>
              <div style={{fontSize:13,fontWeight:700,color:y.profitColor}}>৳{y.profit}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Break-Even Analysis */}
      <div className="grid-2" style={{gap:16,marginBottom:16}}>
        <div className="card">
          <div className="card-title mb-3">🧮 Break-Even Analysis</div>
          <div style={{display:'flex',flexDirection:'column',gap:8}}>
            {[
              ['Avg Selling Price',          `BDT ${systemConfig.avgSellingPrice}`],
              ['Variable Cost (38%)',         `BDT ${varCost}`],
              ['Contribution Margin/Order',   `BDT ${contribution} (${100-systemConfig.variableCostPercent}%)`],
              ['Annual Fixed Costs',          formatCurrency(annualFixed)],
              ['Break-Even Orders/Year',      breakEvenOrders.toLocaleString()],
              ['Break-Even Orders/DAY',       `${breakEvenPerDay} orders`, true],
            ].map(([l,v,highlight]) => (
              <div key={l} style={{
                display:'flex',justifyContent:'space-between',
                padding:'8px 12px',borderRadius:8,
                background:highlight?'var(--pink-light)':'var(--bg)',
                border:highlight?'1.5px solid var(--pink)':'none',
              }}>
                <span style={{fontSize:13,color:highlight?'var(--pink-dark)':'var(--text-muted)'}}>{l}</span>
                <span style={{fontWeight:700,color:highlight?'var(--pink)':'var(--text)'}}>{v}</span>
              </div>
            ))}
          </div>
          <div style={{marginTop:12}}>
            <div style={{display:'flex',justifyContent:'space-between',fontSize:13,marginBottom:4}}>
              <span>Today: {todayOrders.length} orders</span>
              <span>{systemConfig.breakEvenOrders} needed</span>
            </div>
            <div className="progress-track" style={{height:12}}>
              <div className="progress-fill progress-pink" style={{width:`${Math.min(100,(todayOrders.length/systemConfig.breakEvenOrders)*100)}%`}}/>
            </div>
          </div>
        </div>

        {/* Editable cost table */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">Fixed Costs (Editable)</div>
            <div style={{fontSize:12,color:'var(--text-muted)'}}>Live recalculation</div>
          </div>
          <div style={{maxHeight:260,overflowY:'auto'}}>
            <table style={{width:'100%',borderCollapse:'collapse'}}>
              <thead>
                <tr>
                  <th style={{textAlign:'left',padding:'6px 8px',fontSize:11,color:'var(--text-muted)',background:'var(--bg)'}}>Item</th>
                  <th style={{textAlign:'right',padding:'6px 8px',fontSize:11,color:'var(--text-muted)',background:'var(--bg)'}}>BDT/Month</th>
                </tr>
              </thead>
              <tbody>
                {fixedCosts.map(c => (
                  <tr key={c.item}>
                    <td style={{padding:'5px 8px',fontSize:12}}>{c.item}</td>
                    <td style={{padding:'5px 8px',textAlign:'right'}}>
                      {c.editable ? (
                        <input
                          type="number"
                          value={c.monthly}
                          onChange={e => updateCost(c.item, e.target.value)}
                          style={{
                            width:80,textAlign:'right',border:'1px solid var(--border)',
                            borderRadius:4,padding:'2px 6px',fontSize:12,
                          }}
                        />
                      ) : (
                        <span style={{fontWeight:600}}>{c.monthly.toLocaleString()}</span>
                      )}
                    </td>
                  </tr>
                ))}
                <tr style={{background:'var(--pink-light)'}}>
                  <td style={{padding:'8px',fontWeight:700,fontSize:13}}>TOTAL</td>
                  <td style={{padding:'8px',fontWeight:800,fontSize:13,color:'var(--pink)',textAlign:'right'}}>
                    {totalFixedMonthly.toLocaleString()}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Partner Distribution */}
      <div className="card">
        <div className="card-header">
          <div className="card-title">Partner Profit Distribution — This Month</div>
          <div style={{fontSize:13,color:'var(--text-muted)'}}>
            Net profit est.: {formatCurrency(Math.max(0,Math.round(netMonthly)))} · Per partner extra: {formatCurrency(Math.round(perPartnerExtra))}
          </div>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:10}}>
          {partners.map(p => (
            <div key={p.name} style={{
              background:p.paidOut?'var(--teal-light)':'var(--bg)',
              borderRadius:10,padding:14,textAlign:'center',
              border:`1.5px solid ${p.paidOut?'var(--teal)':'var(--border)'}`,
            }}>
              <div style={{
                width:40,height:40,borderRadius:'50%',
                background:p.paidOut?'var(--teal)':'var(--text-muted)',
                color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',
                margin:'0 auto 8px',fontWeight:700,fontSize:18
              }}>{p.name.charAt(0)}</div>
              <div style={{fontWeight:700,fontSize:14}}>{p.name}</div>
              <div style={{fontSize:11,color:'var(--text-muted)',marginTop:2}}>Drawing: BDT 6,000</div>
              <div style={{fontSize:12,fontWeight:600,color:'var(--teal)',marginTop:2}}>
                +{formatCurrency(Math.round(perPartnerExtra))}
              </div>
              {p.paidOut ? (
                <span className="badge badge-success mt-2">✓ Paid</span>
              ) : (
                <button
                  className="btn btn-primary btn-sm mt-2"
                  style={{width:'100%'}}
                  onClick={() => markPartnerPaid(p.name)}
                >
                  Mark Paid
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
