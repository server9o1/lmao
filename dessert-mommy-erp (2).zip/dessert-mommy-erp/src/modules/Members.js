import React, { useState } from 'react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';
import { useApp } from '../context/AppContext';
import { TIER_CONFIG, generateUsername, formatCurrency } from '../mockData';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

export default function Members() {
  const { state, dispatch, addToast, showPhoneMockup } = useApp();

  const [search, setSearch]               = useState('');
  const [tierFilter, setTierFilter]       = useState('All');
  const [sortKey, setSortKey]             = useState('name');
  const [sortDir, setSortDir]             = useState('asc');
  const [selectedMember, setSelectedMember] = useState(null);
  const [showNewForm, setShowNewForm]     = useState(false);
  const [showBonusModal, setShowBonusModal] = useState(false);
  const [bonusPts, setBonusPts]           = useState('');
  const [bonusReason, setBonusReason]     = useState('');
  const [newForm, setNewForm]             = useState({ name:'', phone:'', birthdayMonth:1, howFound:'Social Media' });

  const filtered = state.members
    .filter(m => {
      const q = search.toLowerCase();
      return (q === '' || m.name.toLowerCase().includes(q) || m.username.toLowerCase().includes(q))
        && (tierFilter === 'All' || m.tier === tierFilter);
    })
    .sort((a,b) => {
      let av = a[sortKey], bv = b[sortKey];
      if (typeof av === 'string') { av = av.toLowerCase(); bv = bv.toLowerCase(); }
      return sortDir === 'asc' ? (av > bv ? 1 : -1) : (av < bv ? 1 : -1);
    });

  function toggleSort(key) {
    if (sortKey === key) setSortDir(d => d==='asc'?'desc':'asc');
    else { setSortKey(key); setSortDir('asc'); }
  }

  function handleRegister() {
    if (!newForm.name || !newForm.phone) { addToast('warning','Name and phone are required.'); return; }
    const username = generateUsername();
    dispatch({ type:'REGISTER_MEMBER', username, ...newForm, birthdayMonth:parseInt(newForm.birthdayMonth) });
    addToast('success', `✅ New member registered! Username: ${username}`);
    showPhoneMockup('wt01', newForm.name, { username });
    setShowNewForm(false);
    setNewForm({ name:'', phone:'', birthdayMonth:1, howFound:'Social Media' });
  }

  function handleBonusPoints() {
    if (!bonusPts || !bonusReason) { addToast('warning','Fill points and reason.'); return; }
    dispatch({ type:'AWARD_BONUS_POINTS', memberId:selectedMember.username, points:parseInt(bonusPts), reason:bonusReason });
    addToast('points', `⭐ ${bonusPts} bonus pts awarded to ${selectedMember.name}`);
    setShowBonusModal(false);
    setBonusPts(''); setBonusReason('');
  }

  const tierDist = ['Bronze','Silver','Gold','Platinum'].map(t => ({
    name:t, value:state.members.filter(m=>m.tier===t).length,
    color:TIER_CONFIG[t].color
  }));

  const memberOrders = selectedMember
    ? state.orders.filter(o => o.memberId === selectedMember.username)
    : [];

  const memberBookings = selectedMember
    ? state.bookings.filter(b => b.memberId === selectedMember.username)
    : [];

  const nextTier = selectedMember && selectedMember.tier !== 'Platinum'
    ? selectedMember.tier === 'Bronze' ? 'Silver'
    : selectedMember.tier === 'Silver' ? 'Gold' : 'Platinum'
    : null;
  const nextThreshold = nextTier ? TIER_CONFIG[nextTier].minPoints : null;
  const pointsPct = nextThreshold
    ? Math.min(100,(selectedMember?.cumulativePoints||0)/nextThreshold*100)
    : 100;

  return (
    <div>
      {/* Top row: search + filter + add */}
      <div style={{display:'flex',gap:10,marginBottom:16,alignItems:'center',flexWrap:'wrap'}}>
        <input
          className="input" style={{flex:1,minWidth:200}}
          placeholder="Search name or username..."
          value={search} onChange={e=>setSearch(e.target.value)}
        />
        <div style={{display:'flex',gap:6}}>
          {['All','Bronze','Silver','Gold','Platinum'].map(t => (
            <button
              key={t}
              className={`btn btn-sm ${tierFilter===t?'btn-primary':'btn-outline'}`}
              onClick={() => setTierFilter(t)}
            >{t}</button>
          ))}
        </div>
        <button className="btn btn-primary btn-sm" onClick={() => setShowNewForm(true)}>
          + New Member
        </button>
      </div>

      <div style={{display:'grid',gridTemplateColumns: selectedMember ? '1fr 45%' : '1fr',gap:16}}>
        {/* Member Table */}
        <div className="card" style={{padding:0}}>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  {[
                    ['username','Username'],['name','Name'],['tier','Tier'],
                    ['cumulativePoints','Cumulative'],['redeemablePoints','Redeemable'],
                    ['totalOrders','Orders'],['totalSpent','Spent'],['lastVisit','Last Visit'],
                  ].map(([k,l]) => (
                    <th key={k} style={{cursor:'pointer',userSelect:'none'}} onClick={()=>toggleSort(k)}>
                      {l} {sortKey===k ? (sortDir==='asc'?'↑':'↓') : ''}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(m => (
                  <tr key={m.username}
                    style={{cursor:'pointer',background:selectedMember?.username===m.username?'var(--pink-light)':''}}
                    onClick={() => setSelectedMember(m)}
                  >
                    <td style={{fontFamily:'monospace',fontWeight:600,fontSize:12}}>{m.username}</td>
                    <td style={{fontWeight:600}}>{m.name}</td>
                    <td><span className={`badge badge-${m.tier.toLowerCase()}`}>{m.tier}</span></td>
                    <td>{m.cumulativePoints.toLocaleString()}</td>
                    <td style={{color:'var(--teal)',fontWeight:600}}>{m.redeemablePoints.toLocaleString()}</td>
                    <td>{m.totalOrders}</td>
                    <td>{formatCurrency(m.totalSpent)}</td>
                    <td style={{color:'var(--text-muted)',fontSize:12}}>{m.lastVisit}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Member Profile Drawer (inline panel) */}
        {selectedMember && (
          <div style={{display:'flex',flexDirection:'column',gap:12}}>
            <div className="card" style={{borderTop:`4px solid ${TIER_CONFIG[selectedMember.tier].color}`}}>
              <div style={{display:'flex',justifyContent:'space-between',marginBottom:14}}>
                <div style={{display:'flex',gap:12,alignItems:'center'}}>
                  <div style={{
                    width:52,height:52,borderRadius:'50%',
                    background:TIER_CONFIG[selectedMember.tier].color,
                    color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',
                    fontSize:22,fontWeight:800
                  }}>{selectedMember.name.charAt(0)}</div>
                  <div>
                    <div style={{fontSize:18,fontWeight:800}}>{selectedMember.name}</div>
                    <div style={{fontSize:12,color:'var(--text-muted)'}}>{selectedMember.username} · {selectedMember.phone}</div>
                    <span className={`badge badge-${selectedMember.tier.toLowerCase()}`}>{selectedMember.tier}</span>
                  </div>
                </div>
                <button onClick={()=>setSelectedMember(null)} style={{background:'none',border:'none',cursor:'pointer',fontSize:20,color:'var(--text-muted)'}}>×</button>
              </div>

              {/* Points Progress */}
              <div style={{background:'var(--bg)',borderRadius:10,padding:12,marginBottom:12}}>
                <div style={{display:'flex',justifyContent:'space-between',fontSize:12,marginBottom:6}}>
                  <span style={{color:'var(--text-muted)',fontWeight:600}}>CUMULATIVE POINTS</span>
                  <span style={{fontWeight:700}}>{selectedMember.cumulativePoints.toLocaleString()}</span>
                </div>
                <div className="progress-track">
                  <div className="progress-fill progress-pink" style={{width:`${pointsPct}%`}}/>
                </div>
                {nextTier && (
                  <div style={{fontSize:11,color:'var(--text-muted)',marginTop:4}}>
                    {(nextThreshold - selectedMember.cumulativePoints).toLocaleString()} pts to {nextTier}
                  </div>
                )}
              </div>

              {/* Quick stats */}
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:12}}>
                {[
                  ['Total Orders', selectedMember.totalOrders],
                  ['Total Spent', formatCurrency(selectedMember.totalSpent)],
                  ['Avg Order', formatCurrency(selectedMember.totalOrders>0?Math.round(selectedMember.totalSpent/selectedMember.totalOrders):0)],
                  ['Birthday', MONTHS[(selectedMember.birthdayMonth||1)-1]],
                ].map(([l,v]) => (
                  <div key={l} style={{background:'var(--bg)',borderRadius:8,padding:10}}>
                    <div style={{fontSize:10,color:'var(--text-muted)',fontWeight:700,textTransform:'uppercase'}}>{l}</div>
                    <div style={{fontSize:15,fontWeight:700,marginTop:2}}>{v}</div>
                  </div>
                ))}
              </div>

              {/* Platinum entitlement */}
              {selectedMember.tier === 'Platinum' && (
                <div style={{background:'var(--teal-light)',borderRadius:8,padding:10,marginBottom:12,fontSize:13,color:'var(--teal-dark)',fontWeight:600}}>
                  💎 1 Free Celebration Hub Basic Package Available
                </div>
              )}

              {/* Action buttons */}
              <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
                <button className="btn btn-secondary btn-sm" onClick={()=>setShowBonusModal(true)}>
                  ⭐ Award Points
                </button>
                <button className="btn btn-outline btn-sm" onClick={()=>showPhoneMockup('wt02',selectedMember.name,{amount:0,points:0,balance:selectedMember.redeemablePoints})}>
                  📱 WhatsApp
                </button>
              </div>
            </div>

            {/* Activity Timeline */}
            <div className="card" style={{maxHeight:320,overflowY:'auto'}}>
              <div className="card-title mb-3">Activity Timeline</div>
              <div className="timeline">
                {[
                  ...memberOrders.map(o => ({
                    key:o.id, icon:'🛒', color:'var(--pink-light)',
                    text:`Order — ${formatCurrency(o.total)} via ${o.payment}${o.points>0?` — +${o.points} pts`:''}`,
                    time:o.timestamp,
                  })),
                  ...memberBookings.map(b => ({
                    key:b.id, icon:'🎉', color:'var(--teal-light)',
                    text:`Celebration: ${b.package} (${b.status})`,
                    time:b.createdAt,
                  })),
                ].sort((a,b) => b.time.localeCompare(a.time))
                 .map(evt => (
                  <div key={evt.key} className="timeline-item">
                    <div className="timeline-dot" style={{background:evt.color}}>{evt.icon}</div>
                    <div className="timeline-content">
                      <div className="timeline-text">{evt.text}</div>
                      <div className="timeline-time">{evt.time.split('T')[0]}</div>
                    </div>
                  </div>
                ))}
                {memberOrders.length === 0 && memberBookings.length === 0 && (
                  <div style={{color:'var(--text-muted)',fontSize:13}}>No activity yet.</div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Tier Distribution Chart */}
      <div className="grid-2" style={{gap:16,marginTop:16}}>
        <div className="card">
          <div className="card-title mb-3">Tier Distribution</div>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie data={tierDist} cx="50%" cy="50%" outerRadius={65} dataKey="value" label={({name,value})=>`${name}: ${value}`}>
                {tierDist.map((e,i) => <Cell key={i} fill={e.color}/>)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="card">
          <div className="card-title mb-3">Member Overview</div>
          <div style={{display:'flex',flexDirection:'column',gap:10}}>
            {['Bronze','Silver','Gold','Platinum'].map(t => {
              const count = state.members.filter(m=>m.tier===t).length;
              const pct = (count/state.members.length)*100;
              return (
                <div key={t}>
                  <div style={{display:'flex',justifyContent:'space-between',fontSize:13,marginBottom:3}}>
                    <span style={{fontWeight:600,color:TIER_CONFIG[t].color}}>{t}</span>
                    <span style={{color:'var(--text-muted)'}}>{count} members</span>
                  </div>
                  <div className="progress-track" style={{height:6}}>
                    <div style={{height:'100%',width:`${pct}%`,background:TIER_CONFIG[t].color,borderRadius:4,transition:'width 0.5s'}}/>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* New Member Modal */}
      {showNewForm && (
        <div className="modal-overlay" onClick={()=>setShowNewForm(false)}>
          <div className="modal" onClick={e=>e.stopPropagation()}>
            <div className="modal-header">
              <div className="modal-title">Register New Member</div>
              <button className="modal-close" onClick={()=>setShowNewForm(false)}>×</button>
            </div>
            <div className="form-group">
              <label>Full Name *</label>
              <input className="input" value={newForm.name} onChange={e=>setNewForm(p=>({...p,name:e.target.value}))} placeholder="e.g. Faisal Karim" />
            </div>
            <div className="form-group">
              <label>WhatsApp Phone *</label>
              <input className="input" value={newForm.phone} onChange={e=>setNewForm(p=>({...p,phone:e.target.value}))} placeholder="+8801XXXXXXXXX" />
            </div>
            <div className="form-group">
              <label>Birthday Month</label>
              <select className="select" value={newForm.birthdayMonth} onChange={e=>setNewForm(p=>({...p,birthdayMonth:e.target.value}))}>
                {MONTHS.map((m,i) => <option key={i+1} value={i+1}>{m}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label>How did they find us?</label>
              <select className="select" value={newForm.howFound} onChange={e=>setNewForm(p=>({...p,howFound:e.target.value}))}>
                {['Social Media','Friend Referral','Walk-in','Online Search','Event'].map(s=><option key={s}>{s}</option>)}
              </select>
            </div>
            <div style={{background:'var(--bg)',borderRadius:8,padding:12,marginBottom:14,fontSize:13,color:'var(--text-muted)'}}>
              A unique member ID (DM-XXXX) will be auto-generated.
            </div>
            <div style={{display:'flex',gap:10}}>
              <button className="btn btn-outline" style={{flex:1}} onClick={()=>setShowNewForm(false)}>Cancel</button>
              <button className="btn btn-primary" style={{flex:1}} onClick={handleRegister}>Register & Send Welcome</button>
            </div>
          </div>
        </div>
      )}

      {/* Bonus Points Modal */}
      {showBonusModal && selectedMember && (
        <div className="modal-overlay" onClick={()=>setShowBonusModal(false)}>
          <div className="modal" onClick={e=>e.stopPropagation()}>
            <div className="modal-header">
              <div className="modal-title">Award Bonus Points — {selectedMember.name}</div>
              <button className="modal-close" onClick={()=>setShowBonusModal(false)}>×</button>
            </div>
            <div className="form-group">
              <label>Points to Award</label>
              <input className="input" type="number" value={bonusPts} onChange={e=>setBonusPts(e.target.value)} placeholder="e.g. 100" />
            </div>
            <div className="form-group">
              <label>Reason</label>
              <input className="input" value={bonusReason} onChange={e=>setBonusReason(e.target.value)} placeholder="e.g. Survey completion, VIP gift" />
            </div>
            <div style={{display:'flex',gap:10,marginTop:16}}>
              <button className="btn btn-outline" style={{flex:1}} onClick={()=>setShowBonusModal(false)}>Cancel</button>
              <button className="btn btn-secondary" style={{flex:1}} onClick={handleBonusPoints}>Award Points</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
