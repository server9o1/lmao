import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { TIER_CONFIG, REWARDS, calculatePoints, getTierFromCumulative, formatCurrency } from '../mockData';

export default function SweetPoints() {
  const { state, dispatch, addToast, showPhoneMockup } = useApp();

  const [calcMember, setCalcMember]     = useState('');
  const [calcTotal, setCalcTotal]       = useState('');
  const [redeemMember, setRedeemMember] = useState('');
  const [redeemReward, setRedeemReward] = useState('');
  const [showRedeemModal, setShowRedeemModal] = useState(false);
  const [bonusMember, setBonusMember]   = useState('');
  const [bonusPts, setBonusPts]         = useState('');
  const [bonusReason, setBonusReason]   = useState('');
  const [expandedRow, setExpandedRow]   = useState(null);

  const MONTH_NAMES = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const currentMonth = new Date().getMonth() + 1;
  const birthdayMembers = state.members.filter(m => m.birthdayMonth === currentMonth);

  // Calc results
  const calcMemberObj = state.members.find(m => m.username === calcMember || m.name.toLowerCase() === calcMember.toLowerCase());
  const calcTotalNum  = parseFloat(calcTotal) || 0;
  const calcPts       = calcMemberObj && calcTotalNum > 0 ? calculatePoints(calcTotalNum, calcMemberObj.tier) : 0;
  const calcNewCum    = calcMemberObj ? calcMemberObj.cumulativePoints + calcPts : 0;
  const calcNewTier   = calcNewCum > 0 ? getTierFromCumulative(calcNewCum) : null;
  const calcNextThreshold = calcNewTier === 'Platinum' ? null
    : calcNewTier === 'Gold' ? 3000
    : calcNewTier === 'Silver' ? 1500 : 500;
  const calcDistance = calcNextThreshold ? calcNextThreshold - calcNewCum : 0;

  function handleRedeem() {
    const m = state.members.find(mb => mb.username === redeemMember);
    const r = REWARDS.find(rr => rr.id === redeemReward);
    if (!m || !r) return;
    if (m.redeemablePoints < r.cost) {
      addToast('error', `Insufficient points. ${m.name} has ${m.redeemablePoints} pts, needs ${r.cost}.`);
      return;
    }
    dispatch({ type:'REDEEM_POINTS', memberId:m.username, rewardCost:r.cost, rewardName:r.name });
    addToast('success', `✅ ${r.name} redeemed for ${m.name} (${r.cost} pts deducted)`);
    showPhoneMockup('wt10', m.name, { points:r.cost, reward:r.name, balance:m.redeemablePoints-r.cost });
    setShowRedeemModal(false);
    setRedeemMember(''); setRedeemReward('');
  }

  function handleBonusPoints() {
    const m = state.members.find(mb => mb.username === bonusMember);
    if (!m || !bonusPts || !bonusReason) { addToast('warning','Fill all fields.'); return; }
    dispatch({ type:'AWARD_BONUS_POINTS', memberId:m.username, points:parseInt(bonusPts), reason:bonusReason });
    addToast('points', `⭐ ${parseInt(bonusPts)} bonus pts awarded to ${m.name}`);
    setBonusMember(''); setBonusPts(''); setBonusReason('');
  }

  return (
    <div>
      {/* Tier Overview */}
      <div className="tier-cards">
        {Object.entries(TIER_CONFIG).map(([tier, cfg]) => {
          const count = state.members.filter(m => m.tier === tier).length;
          return (
            <div key={tier} className="tier-card" style={{borderLeftColor:cfg.color}}>
              <div className="tier-name" style={{color:cfg.color}}>{tier}</div>
              <div className="tier-threshold" style={{color:'var(--text-muted)'}}>
                {tier === 'Bronze' ? '0 pts' : `${cfg.minPoints.toLocaleString()}+ pts`}
              </div>
              <div className="tier-multiplier" style={{color:cfg.color}}>{cfg.multiplier}×</div>
              <div className="tier-count" style={{color:cfg.color}}>
                {count} member{count !== 1 ? 's' : ''}
              </div>
              <ul className="tier-benefits">
                {cfg.benefits.map(b => (
                  <li key={b} style={{color:'var(--text-muted)'}}>{b}</li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>

      <div className="grid-2" style={{gap:16}}>
        {/* Member Points Ledger */}
        <div className="card" style={{gridColumn:'1 / -1'}}>
          <div className="card-header">
            <div className="card-title">Member Points Ledger</div>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Username</th>
                  <th>Name</th>
                  <th>Tier</th>
                  <th>Cumulative</th>
                  <th>Redeemable</th>
                  <th>Next Tier</th>
                  <th>Last Visit</th>
                </tr>
              </thead>
              <tbody>
                {state.members.map(m => {
                  const nextThresh = m.tier==='Platinum' ? null : TIER_CONFIG[
                    m.tier==='Bronze'?'Silver':m.tier==='Silver'?'Gold':'Platinum'
                  ].minPoints;
                  const pctToNext = nextThresh ? Math.min(100,(m.cumulativePoints/nextThresh)*100) : 100;

                  return (
                    <React.Fragment key={m.username}>
                      <tr style={{cursor:'pointer'}} onClick={() => setExpandedRow(expandedRow===m.username?null:m.username)}>
                        <td style={{fontWeight:600}}>{m.username}</td>
                        <td>{m.name}</td>
                        <td><span className={`badge badge-${m.tier.toLowerCase()}`}>{m.tier}</span></td>
                        <td style={{fontWeight:600}}>{m.cumulativePoints.toLocaleString()}</td>
                        <td style={{color:'var(--teal)',fontWeight:600}}>{m.redeemablePoints.toLocaleString()}</td>
                        <td>
                          {nextThresh ? (
                            <div>
                              <div style={{fontSize:11,color:'var(--text-muted)',marginBottom:3}}>
                                {(nextThresh - m.cumulativePoints).toLocaleString()} pts away
                              </div>
                              <div className="progress-track" style={{height:5}}>
                                <div className="progress-fill progress-pink" style={{width:`${pctToNext}%`}} />
                              </div>
                            </div>
                          ) : <span className="badge badge-platinum">MAX</span>}
                        </td>
                        <td style={{color:'var(--text-muted)',fontSize:12}}>{m.lastVisit}</td>
                      </tr>
                      {expandedRow === m.username && (
                        <tr>
                          <td colSpan={7} style={{padding:0}}>
                            <div style={{padding:'12px 16px',background:'var(--bg)',borderBottom:'1px solid var(--border)'}}>
                              <div className="section-label">Points Transaction History</div>
                              <div className="timeline" style={{marginTop:8}}>
                                {state.orders.filter(o=>o.memberId===m.username).map(o => (
                                  <div key={o.id} className="timeline-item">
                                    <div className="timeline-dot" style={{background:'var(--pink-light)'}}>🛒</div>
                                    <div className="timeline-content">
                                      <div className="timeline-text">
                                        Order — {formatCurrency(o.total)} via {o.payment}
                                        {o.points > 0 && <span style={{color:'var(--pink)',fontWeight:600}}> +{o.points} pts</span>}
                                      </div>
                                      <div className="timeline-time">{o.timestamp.split('T')[0]} · {o.timestamp.split('T')[1].slice(0,5)}</div>
                                    </div>
                                  </div>
                                ))}
                                {state.orders.filter(o=>o.memberId===m.username).length === 0 && (
                                  <div style={{color:'var(--text-muted)',fontSize:13}}>No transactions yet.</div>
                                )}
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="grid-2" style={{gap:16,marginTop:16}}>
        {/* Points Simulator */}
        <div className="card">
          <div className="card-title mb-3">🧮 Points Calculator</div>
          <div className="form-group">
            <label>Member Username or Name</label>
            <input className="input" value={calcMember} onChange={e=>setCalcMember(e.target.value)}
              placeholder="e.g. DM-4A9F or Arif Rahman" />
          </div>
          <div className="form-group">
            <label>Order Total (BDT)</label>
            <input className="input" type="number" value={calcTotal} onChange={e=>setCalcTotal(e.target.value)}
              placeholder="e.g. 598" />
          </div>
          {calcMemberObj && calcTotalNum > 0 && (
            <div className="calc-result">
              <div className="calc-line">
                <span>Member</span><span>{calcMemberObj.name}</span>
              </div>
              <div className="calc-line">
                <span>Current Tier</span>
                <span className="calc-highlight">{calcMemberObj.tier} ({TIER_CONFIG[calcMemberObj.tier].multiplier}×)</span>
              </div>
              <div className="calc-line">
                <span>Order Total</span><span>{formatCurrency(calcTotalNum)}</span>
              </div>
              <div className="calc-line">
                <span>Points Formula</span>
                <span>⌊{calcTotalNum} × {TIER_CONFIG[calcMemberObj.tier].multiplier}⌋</span>
              </div>
              <div className="calc-line">
                <span>Points Earned</span>
                <span className="calc-highlight">+{calcPts} pts</span>
              </div>
              <div className="calc-line">
                <span>New Cumulative</span>
                <span>{calcNewCum.toLocaleString()}</span>
              </div>
              {calcNewTier !== calcMemberObj.tier && (
                <div className="calc-line" style={{color:'#F9A825',fontWeight:800}}>
                  <span>🎉 TIER UPGRADE!</span><span>{calcMemberObj.tier} → {calcNewTier}</span>
                </div>
              )}
              {calcDistance > 0 && calcNewTier === calcMemberObj.tier && (
                <div className="calc-line">
                  <span>Distance to {getTierFromCumulative(calcNextThreshold)}</span>
                  <span>{calcDistance.toLocaleString()} pts</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Redemption Panel */}
        <div className="card">
          <div className="card-title mb-3">🎁 Points Redemption</div>
          <div className="form-group">
            <label>Member Username</label>
            <select className="select" value={redeemMember} onChange={e=>setRedeemMember(e.target.value)}>
              <option value="">— Select member —</option>
              {state.members.map(m => (
                <option key={m.username} value={m.username}>
                  {m.name} ({m.username}) — {m.redeemablePoints} pts
                </option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Select Reward</label>
            <div style={{display:'flex',flexDirection:'column',gap:8}}>
              {REWARDS.map(r => {
                const m = state.members.find(mb=>mb.username===redeemMember);
                const canRedeem = m && m.redeemablePoints >= r.cost;
                return (
                  <div
                    key={r.id}
                    onClick={() => canRedeem && setRedeemReward(r.id)}
                    style={{
                      padding:'10px 14px',border:`1.5px solid ${redeemReward===r.id?'var(--teal)':'var(--border)'}`,
                      borderRadius:8,cursor:canRedeem?'pointer':'not-allowed',
                      opacity:canRedeem?1:0.4,
                      background:redeemReward===r.id?'var(--teal-light)':'var(--white)',
                      display:'flex',justifyContent:'space-between',alignItems:'center'
                    }}
                  >
                    <div>
                      <div style={{fontWeight:600,fontSize:14}}>{r.name}</div>
                      <div style={{fontSize:12,color:'var(--text-muted)'}}>{r.description}</div>
                    </div>
                    <span style={{fontWeight:700,color:'var(--teal)'}}>{r.cost} pts</span>
                  </div>
                );
              })}
            </div>
          </div>
          <button
            className="btn btn-secondary"
            style={{width:'100%'}}
            onClick={() => redeemMember && redeemReward && setShowRedeemModal(true)}
            disabled={!redeemMember || !redeemReward}
          >
            Redeem Points
          </button>
        </div>
      </div>

      {/* Birthday Panel */}
      {birthdayMembers.length > 0 && (
        <div className="card mt-4" style={{borderTop:'4px solid var(--pink)'}}>
          <div className="card-title mb-3">
            🎂 Birthday Members — {MONTH_NAMES[currentMonth-1]}
          </div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12}}>
            {birthdayMembers.map(m => (
              <div key={m.username} style={{
                background:'var(--pink-light)',borderRadius:10,padding:14,
                display:'flex',justifyContent:'space-between',alignItems:'center'
              }}>
                <div>
                  <div style={{fontWeight:600,fontSize:14}}>{m.name}</div>
                  <div style={{fontSize:12,color:'var(--text-muted)'}}>{m.username} · {m.tier}</div>
                </div>
                <button
                  className="btn btn-primary btn-sm"
                  onClick={() => showPhoneMockup('wt06', m.name)}
                >
                  🎂 Send Wish
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Bonus Points Panel */}
      <div className="card mt-4">
        <div className="card-title mb-3">⭐ Award Bonus Points</div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr auto',gap:10,alignItems:'end'}}>
          <div>
            <label>Member</label>
            <select className="select" value={bonusMember} onChange={e=>setBonusMember(e.target.value)}>
              <option value="">— Select —</option>
              {state.members.map(m => <option key={m.username} value={m.username}>{m.name}</option>)}
            </select>
          </div>
          <div>
            <label>Points</label>
            <input className="input" type="number" value={bonusPts} onChange={e=>setBonusPts(e.target.value)} placeholder="e.g. 100" />
          </div>
          <div>
            <label>Reason</label>
            <input className="input" value={bonusReason} onChange={e=>setBonusReason(e.target.value)} placeholder="e.g. Feedback survey" />
          </div>
          <button className="btn btn-secondary" onClick={handleBonusPoints} style={{height:42}}>
            Award
          </button>
        </div>
      </div>

      {/* Redemption Confirm Modal */}
      {showRedeemModal && (
        <div className="modal-overlay" onClick={()=>setShowRedeemModal(false)}>
          <div className="modal" onClick={e=>e.stopPropagation()}>
            <div className="modal-header">
              <div className="modal-title">Confirm Redemption</div>
              <button className="modal-close" onClick={()=>setShowRedeemModal(false)}>×</button>
            </div>
            {(() => {
              const m = state.members.find(mb=>mb.username===redeemMember);
              const r = REWARDS.find(rr=>rr.id===redeemReward);
              if (!m || !r) return null;
              return (
                <>
                  <p style={{fontSize:14,lineHeight:1.6,color:'var(--text-muted)',marginBottom:16}}>
                    Redeem <strong>{r.name}</strong> for <strong>{m.name}</strong>?<br/>
                    <strong>{r.cost} pts</strong> will be deducted.<br/>
                    New balance: <strong>{m.redeemablePoints - r.cost} pts</strong>
                  </p>
                  <div style={{display:'flex',gap:10}}>
                    <button className="btn btn-outline" style={{flex:1}} onClick={()=>setShowRedeemModal(false)}>Cancel</button>
                    <button className="btn btn-secondary" style={{flex:1}} onClick={handleRedeem}>Confirm Redemption</button>
                  </div>
                </>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
}
