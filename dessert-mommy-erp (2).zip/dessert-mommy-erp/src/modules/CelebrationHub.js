import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PACKAGES, formatCurrency } from '../mockData';

const THEMES = ['Chocolate','Strawberry','Pastel','Cartoon','Romantic'];
const TIME_SLOTS = ['12:00 PM','1:00 PM','2:00 PM','3:00 PM','4:00 PM','5:00 PM','6:00 PM','7:00 PM','8:00 PM','9:00 PM','10:00 PM'];
const STATUS_PIPELINE = ['Inquiry','Pending Payment','Confirmed','Preparation','Active','Completed'];

const STATUS_MAP = {
  inquiry:         { label:'Inquiry',         color:'#FF9800', step:0 },
  pending_payment: { label:'Pending Payment', color:'#FF9800', step:1 },
  confirmed:       { label:'Confirmed',       color:'var(--teal)',  step:2 },
  preparation:     { label:'Preparation',     color:'#1565C0', step:3 },
  active:          { label:'Active',           color:'var(--pink)',  step:4 },
  completed:       { label:'Completed',       color:'var(--teal)',  step:5 },
};

export default function CelebrationHub() {
  const { state, dispatch, addToast, showPhoneMockup } = useApp();

  const [view, setView] = useState('calendar'); // 'calendar' | 'new' | 'detail'
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [showPayModal, setShowPayModal] = useState(false);
  const [payMethod, setPayMethod] = useState('bKash');
  const [newBooking, setNewBooking] = useState({ memberId:'',memberName:'',eventType:'Birthday',date:'',timeSlot:'6:00 PM',package:'',theme:'Strawberry',partySize:4,addons:[],specialNotes:'' });
  const [showCompleteModal, setShowCompleteModal] = useState(false);
  const [attendees, setAttendees] = useState('');

  const today = new Date().toISOString().split('T')[0];

  // Build calendar for current month
  const now = new Date();
  const year = now.getFullYear(), month = now.getMonth();
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month+1, 0).getDate();
  const calDays = [];
  for (let i = 0; i < firstDay; i++) calDays.push(null);
  for (let d = 1; d <= daysInMonth; d++) calDays.push(d);

  function getDateStr(d) {
    const m = String(month+1).padStart(2,'0'), dd=String(d).padStart(2,'0');
    return `${year}-${m}-${dd}`;
  }

  function bookingsForDate(d) {
    return state.bookings.filter(b => b.date === getDateStr(d));
  }

  const selectedPackage = PACKAGES.find(p => p.name === newBooking.package);
  const addonTotal = 1200; // simplify
  const bookingTotal = selectedPackage ? selectedPackage.price + (newBooking.addons.length ? addonTotal : 0) : 0;

  function handleMemberLookup(val) {
    const m = state.members.find(mb => mb.username === val || mb.name.toLowerCase() === val.toLowerCase());
    if (m) setNewBooking(prev => ({ ...prev, memberId:m.username, memberName:m.name }));
    else setNewBooking(prev => ({ ...prev, memberId:val, memberName:val }));
  }

  function submitBooking() {
    if (!newBooking.memberId || !newBooking.date || !newBooking.package) {
      addToast('warning','Please fill in all required fields.'); return;
    }
    dispatch({ type:'CREATE_BOOKING', booking:{
      ...newBooking,
      packagePrice: selectedPackage?.price || 0,
      advance: Math.ceil(bookingTotal / 2),
      balance: Math.ceil(bookingTotal / 2),
      decorationChecklist:{ balloons:false,bannerHung:false,tableSet:false,lightingReady:false,photoProps:false },
      createdAt: today,
    }});
    addToast('success','Booking created! Record advance payment to confirm.');
    setShowPayModal(true);
  }

  function confirmPayment() {
    // Find the newest pending_payment booking
    const pending = [...state.bookings].reverse().find(b => b.status === 'pending_payment');
    if (pending) {
      dispatch({ type:'UPDATE_BOOKING_STATUS', id:pending.id, status:'confirmed' });
      addToast('success',`✅ Advance payment confirmed via ${payMethod}! Booking is now CONFIRMED.`);
      showPhoneMockup('wt07', pending.memberName, {
        date: pending.date, time: pending.timeSlot || '6:00 PM',
        package: pending.package, theme: pending.theme,
        guests: pending.partySize, advance: pending.advance, balance: pending.balance,
      });
    }
    setShowPayModal(false);
    setView('calendar');
    setNewBooking({ memberId:'',memberName:'',eventType:'Birthday',date:'',timeSlot:'6:00 PM',package:'',theme:'Strawberry',partySize:4,addons:[],specialNotes:'' });
  }

  function handleComplete(b) {
    setSelectedBooking(b);
    setShowCompleteModal(true);
  }

  function confirmComplete() {
    if (!selectedBooking) return;
    const usernames = attendees.split(',').map(s=>s.trim()).filter(Boolean);
    dispatch({ type:'COMPLETE_BOOKING_WITH_POINTS', bookingId:selectedBooking.id, attendeeUsernames:usernames });
    addToast('success',`Event completed! ${usernames.length} attendees awarded 200 pts each.`);
    setShowCompleteModal(false);
    setSelectedBooking(null);
    setAttendees('');
  }

  return (
    <div>
      {/* Tab bar */}
      <div style={{display:'flex',gap:8,marginBottom:16}}>
        {[['calendar','📅 Calendar'],['new','➕ New Booking'],['list','📋 All Bookings']].map(([id,label]) => (
          <button
            key={id} className={`btn ${view===id?'btn-primary':'btn-outline'} btn-sm`}
            onClick={() => setView(id)}
          >{label}</button>
        ))}
      </div>

      {/* ── Calendar View ───────────────────────────── */}
      {view === 'calendar' && (
        <div className="grid-2" style={{gap:16,alignItems:'start'}}>
          <div className="card">
            <div className="card-header">
              <div className="card-title">
                {now.toLocaleString('default',{month:'long'})} {year}
              </div>
              <div style={{display:'flex',gap:8,fontSize:12}}>
                {[{c:'var(--pink)',n:'Confirmed'},{c:'#F9A825',n:'Pending'},{c:'var(--text-muted)',n:'Done'}].map(l=>(
                  <div key={l.n} style={{display:'flex',alignItems:'center',gap:4}}>
                    <div style={{width:8,height:8,borderRadius:'50%',background:l.c}}/>
                    {l.n}
                  </div>
                ))}
              </div>
            </div>
            <div className="calendar-grid">
              {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => (
                <div key={d} className="cal-day-header">{d}</div>
              ))}
              {calDays.map((d, i) => {
                if (!d) return <div key={`e${i}`} />;
                const ds = getDateStr(d);
                const dayBookings = bookingsForDate(d);
                const isToday = ds === today;
                const isFull = dayBookings.length >= 2;
                return (
                  <div
                    key={d}
                    className={`cal-day ${isToday?'today':''} ${isFull?'full':''}`}
                    onClick={() => { setSelectedDate(d); }}
                    style={{ outline: selectedDate===d ? '2px solid var(--pink)' : '' }}
                  >
                    <div className="cal-day-num">{d}</div>
                    {isFull && <div style={{fontSize:9,color:'#E65100',fontWeight:700}}>FULL</div>}
                    <div className="cal-dots">
                      {dayBookings.map(b => (
                        <div key={b.id} className={`cal-dot cal-dot-${b.status === 'completed' ? 'completed' : b.status==='confirmed'?'confirmed':'pending'}`} />
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Day detail panel */}
          <div>
            {selectedDate ? (
              <div className="card">
                <div className="card-header">
                  <div className="card-title">
                    {new Date(getDateStr(selectedDate)).toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'})}
                  </div>
                  <button className="btn btn-primary btn-sm" onClick={() => { setView('new'); setNewBooking(prev=>({...prev,date:getDateStr(selectedDate)})); }}>
                    + Book
                  </button>
                </div>
                {bookingsForDate(selectedDate).length > 0 ? (
                  <div style={{display:'flex',flexDirection:'column',gap:10}}>
                    {bookingsForDate(selectedDate).map(b => (
                      <div key={b.id} style={{
                        border:'1.5px solid var(--border)',borderRadius:10,padding:14,cursor:'pointer'
                      }}
                        onClick={() => { setSelectedBooking(b); setView('detail'); }}
                      >
                        <div style={{display:'flex',justifyContent:'space-between',marginBottom:6}}>
                          <span style={{fontWeight:700}}>{b.memberName}</span>
                          <span className="badge" style={{
                            background:`${STATUS_MAP[b.status]?.color}20`,
                            color:STATUS_MAP[b.status]?.color
                          }}>{STATUS_MAP[b.status]?.label}</span>
                        </div>
                        <div style={{fontSize:12,color:'var(--text-muted)'}}>
                          {b.package} · {b.timeSlot} · {b.partySize} guests
                        </div>
                        <div style={{fontSize:12,fontWeight:600,color:'var(--pink)',marginTop:4}}>
                          {formatCurrency(b.packagePrice)}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="empty-state">
                    <div className="icon">📅</div>
                    <p>No bookings on this day. Click + Book to add one.</p>
                  </div>
                )}
              </div>
            ) : (
              <div className="card">
                <div style={{color:'var(--text-muted)',fontSize:14,padding:20,textAlign:'center'}}>
                  Click a calendar date to view bookings.
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── New Booking Form ─────────────────────────── */}
      {view === 'new' && (
        <div className="grid-2" style={{gap:16,alignItems:'start'}}>
          <div style={{display:'flex',flexDirection:'column',gap:12}}>
            <div className="card">
              <div className="card-title mb-3">New Celebration Booking</div>
              <div className="form-group">
                <label>Member Username</label>
                <input className="input" placeholder="e.g. DM-4A9F" onBlur={e=>handleMemberLookup(e.target.value)} defaultValue={newBooking.memberId} />
                {newBooking.memberName && <div style={{fontSize:12,color:'var(--teal)',marginTop:4}}>✓ {newBooking.memberName}</div>}
              </div>
              <div className="form-group">
                <label>Event Type</label>
                <select className="select" value={newBooking.eventType} onChange={e=>setNewBooking(p=>({...p,eventType:e.target.value}))}>
                  {['Birthday','Anniversary','Group Celebration','Other'].map(t=><option key={t}>{t}</option>)}
                </select>
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label>Date</label>
                  <input className="input" type="date" value={newBooking.date} min={today}
                    onChange={e=>setNewBooking(p=>({...p,date:e.target.value}))} />
                </div>
                <div className="form-group">
                  <label>Time Slot</label>
                  <select className="select" value={newBooking.timeSlot} onChange={e=>setNewBooking(p=>({...p,timeSlot:e.target.value}))}>
                    {TIME_SLOTS.map(t=><option key={t}>{t}</option>)}
                  </select>
                </div>
              </div>
              <div className="form-group">
                <label>Party Size</label>
                <input className="input" type="number" min={1} value={newBooking.partySize}
                  onChange={e=>setNewBooking(p=>({...p,partySize:parseInt(e.target.value)||1}))} />
              </div>
            </div>

            <div className="card">
              <div className="card-title mb-3">Theme</div>
              <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
                {THEMES.map(t => (
                  <div key={t}
                    onClick={()=>setNewBooking(p=>({...p,theme:t}))}
                    style={{
                      padding:'8px 14px',borderRadius:20,cursor:'pointer',
                      border:`2px solid ${newBooking.theme===t?'var(--pink)':'var(--border)'}`,
                      background:newBooking.theme===t?'var(--pink-light)':'var(--white)',
                      fontWeight:600,fontSize:13,
                      color:newBooking.theme===t?'var(--pink)':'var(--text)',
                    }}>{t}</div>
                ))}
              </div>
            </div>

            <div className="card">
              <div className="card-title mb-2">Add-ons</div>
              <label style={{display:'flex',alignItems:'center',gap:8,cursor:'pointer',padding:'8px 0'}}>
                <input type="checkbox" checked={newBooking.addons.includes('bouquet')}
                  onChange={e=>setNewBooking(p=>({...p,addons:e.target.checked?['bouquet']:[]}))} />
                <span>Chocolate Bouquet (BDT 600–3,000)</span>
              </label>
            </div>

            <div className="card">
              <label className="card-title" style={{marginBottom:8,display:'block'}}>Special Notes</label>
              <textarea className="input" rows={3} value={newBooking.specialNotes}
                onChange={e=>setNewBooking(p=>({...p,specialNotes:e.target.value}))}
                placeholder="Dietary requirements, surprise elements, etc." />
            </div>
          </div>

          <div style={{display:'flex',flexDirection:'column',gap:12}}>
            {/* Package Selector */}
            <div className="card">
              <div className="card-title mb-3">Select Package</div>
              {PACKAGES.map(pkg => (
                <div
                  key={pkg.name}
                  onClick={()=>setNewBooking(p=>({...p,package:pkg.name}))}
                  style={{
                    border:`2px solid ${newBooking.package===pkg.name?pkg.color:'var(--border)'}`,
                    borderRadius:10,padding:14,marginBottom:10,cursor:'pointer',
                    background:newBooking.package===pkg.name?`${pkg.color}12`:'var(--white)',
                  }}
                >
                  <div style={{display:'flex',justifyContent:'space-between',marginBottom:6}}>
                    <span style={{fontWeight:700,fontSize:15,color:pkg.color}}>{pkg.name}</span>
                    <span style={{fontWeight:800,color:pkg.color}}>{formatCurrency(pkg.price)}</span>
                  </div>
                  <ul style={{listStyle:'none',padding:0}}>
                    {pkg.inclusions.map(inc => (
                      <li key={inc} style={{fontSize:12,color:'var(--text-muted)',padding:'1px 0',display:'flex',gap:6,alignItems:'center'}}>
                        <span style={{color:pkg.color}}>✓</span>{inc}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            {/* Booking Summary */}
            {selectedPackage && (
              <div className="card" style={{borderTop:`4px solid var(--pink)`}}>
                <div className="card-title mb-3">Booking Summary</div>
                <div style={{display:'flex',flexDirection:'column',gap:8}}>
                  {[
                    ['Package',formatCurrency(selectedPackage.price)],
                    ['Add-ons',newBooking.addons.length?formatCurrency(addonTotal):'—'],
                    ['Total',formatCurrency(bookingTotal)],
                    ['Advance (50%)',formatCurrency(Math.ceil(bookingTotal/2)),'var(--pink)'],
                    ['Balance (on event day)',formatCurrency(Math.floor(bookingTotal/2)),'var(--text-muted)'],
                  ].map(([l,v,c]) => (
                    <div key={l} style={{display:'flex',justifyContent:'space-between',fontSize:14,padding:'4px 0',borderBottom:'1px solid var(--border)'}}>
                      <span style={{color:'var(--text-muted)'}}>{l}</span>
                      <span style={{fontWeight:700,color:c||'var(--text)'}}>{v}</span>
                    </div>
                  ))}
                </div>
                <button className="btn btn-primary mt-4" style={{width:'100%'}} onClick={submitBooking}>
                  Submit Booking Request
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── All Bookings List ───────────────────────── */}
      {view === 'list' && (
        <div className="card">
          <div className="card-title mb-3">All Bookings</div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr><th>ID</th><th>Customer</th><th>Package</th><th>Date</th><th>Status</th><th>Total</th><th>Actions</th></tr>
              </thead>
              <tbody>
                {state.bookings.map(b => (
                  <tr key={b.id}>
                    <td style={{fontFamily:'monospace',fontSize:12}}>{b.id}</td>
                    <td style={{fontWeight:600}}>{b.memberName}</td>
                    <td>{b.package}</td>
                    <td>{b.date} {b.timeSlot}</td>
                    <td><span className="badge" style={{
                      background:`${STATUS_MAP[b.status]?.color}20`,
                      color:STATUS_MAP[b.status]?.color
                    }}>{STATUS_MAP[b.status]?.label}</span></td>
                    <td>{formatCurrency(b.packagePrice)}</td>
                    <td>
                      <div style={{display:'flex',gap:6}}>
                        <button className="btn btn-outline btn-sm"
                          onClick={() => { setSelectedBooking(b); setView('detail'); }}>
                          View
                        </button>
                        {b.status === 'confirmed' && (
                          <button className="btn btn-sm btn-success"
                            onClick={() => handleComplete(b)}>
                            Complete
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── Booking Detail ───────────────────────────── */}
      {view === 'detail' && selectedBooking && (
        <div>
          <button className="btn btn-ghost btn-sm mb-3" onClick={() => { setView('list'); setSelectedBooking(null); }}>
            ← Back to list
          </button>
          <div className="grid-2" style={{gap:16}}>
            <div style={{display:'flex',flexDirection:'column',gap:12}}>
              <div className="card">
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'start',marginBottom:16}}>
                  <div>
                    <div style={{fontSize:20,fontWeight:800}}>{selectedBooking.memberName}</div>
                    <div style={{color:'var(--text-muted)',fontSize:13}}>{selectedBooking.memberId}</div>
                  </div>
                  <span className="badge badge-lg" style={{
                    background:`${STATUS_MAP[selectedBooking.status]?.color}20`,
                    color:STATUS_MAP[selectedBooking.status]?.color,
                    fontSize:13,padding:'5px 14px'
                  }}>{STATUS_MAP[selectedBooking.status]?.label}</span>
                </div>

                {/* Status Pipeline */}
                <div className="status-pipeline">
                  {STATUS_PIPELINE.map((s, i) => {
                    const step = STATUS_MAP[selectedBooking.status]?.step ?? -1;
                    const done = i < step, active = i === step;
                    return (
                      <React.Fragment key={s}>
                        <div className="pipeline-step">
                          <div className={`pipeline-dot ${done?'done':''} ${active?'active':''}`}>
                            {done ? '✓' : active ? '●' : ''}
                          </div>
                          <div className="pipeline-label">{s}</div>
                        </div>
                        {i < STATUS_PIPELINE.length-1 && (
                          <div className={`pipeline-line ${done?'done':''}`} />
                        )}
                      </React.Fragment>
                    );
                  })}
                </div>

                <div className="divider" />
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                  {[
                    ['Package', selectedBooking.package],
                    ['Date', selectedBooking.date],
                    ['Time', selectedBooking.timeSlot],
                    ['Theme', selectedBooking.theme],
                    ['Guests', selectedBooking.partySize],
                    ['Total', formatCurrency(selectedBooking.packagePrice)],
                    ['Advance Paid', formatCurrency(selectedBooking.advance)],
                    ['Balance Due', formatCurrency(selectedBooking.balance)],
                  ].map(([l,v]) => (
                    <div key={l}>
                      <div style={{fontSize:11,color:'var(--text-muted)',fontWeight:700,textTransform:'uppercase'}}>{l}</div>
                      <div style={{fontSize:14,fontWeight:600}}>{v}</div>
                    </div>
                  ))}
                </div>

                <div className="divider" />
                <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
                  <button className="btn btn-outline btn-sm"
                    onClick={() => showPhoneMockup('wt08', selectedBooking.memberName, {
                      package:selectedBooking.package,
                      time:selectedBooking.timeSlot,
                      theme:selectedBooking.theme,
                      guests:selectedBooking.partySize,
                    })}>
                    📱 Day-Of Alert
                  </button>
                  <button className="btn btn-outline btn-sm"
                    onClick={() => showPhoneMockup('wt12', selectedBooking.memberName, {
                      date:selectedBooking.date, time:selectedBooking.timeSlot,
                      package:selectedBooking.package, balance:selectedBooking.balance,
                    })}>
                    📱 Send Reminder
                  </button>
                  {selectedBooking.status === 'confirmed' && (
                    <button className="btn btn-success btn-sm"
                      onClick={() => handleComplete(selectedBooking)}>
                      ✅ Mark Complete
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Decoration Checklist */}
            <div className="card">
              <div className="card-title mb-3">🎨 Decoration Checklist</div>
              <div className="checklist">
                {Object.entries(selectedBooking.decorationChecklist || {}).map(([item, checked]) => (
                  <div
                    key={item}
                    className={`check-item ${checked?'checked':''}`}
                    onClick={() => dispatch({
                      type:'UPDATE_DECORATION_CHECKLIST',
                      id:selectedBooking.id, item, value:!checked
                    })}
                  >
                    <div className="check-box">{checked?'✓':''}</div>
                    <span className="check-label">
                      {item === 'balloons' ? '🎈 Balloons inflated'
                        : item === 'bannerHung' ? '🎊 Banner hung'
                        : item === 'tableSet' ? '🍽️ Table set'
                        : item === 'lightingReady' ? '💡 Lighting ready'
                        : '📸 Photo props placed'}
                    </span>
                  </div>
                ))}
              </div>
              <div style={{marginTop:14,padding:12,background:'var(--bg)',borderRadius:8,fontSize:13,color:'var(--text-muted)'}}>
                ✅ {Object.values(selectedBooking.decorationChecklist||{}).filter(Boolean).length} of {Object.keys(selectedBooking.decorationChecklist||{}).length} items ready
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Payment Modal */}
      {showPayModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <div className="modal-title">Record Advance Payment</div>
              <button className="modal-close" onClick={()=>setShowPayModal(false)}>×</button>
            </div>
            <p style={{fontSize:14,color:'var(--text-muted)',marginBottom:16}}>
              Record the advance payment (50%) to confirm this booking.
            </p>
            <div className="form-group">
              <label>Payment Method</label>
              <div className="payment-toggle">
                {['Cash','bKash','Nagad'].map(m => (
                  <button key={m} className={`payment-btn ${payMethod===m?'active':''}`} onClick={()=>setPayMethod(m)}>{m}</button>
                ))}
              </div>
            </div>
            <div style={{display:'flex',gap:10,marginTop:16}}>
              <button className="btn btn-outline" style={{flex:1}} onClick={()=>setShowPayModal(false)}>Later</button>
              <button className="btn btn-primary" style={{flex:1}} onClick={confirmPayment}>
                Confirm Payment via {payMethod}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Complete Modal */}
      {showCompleteModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <div className="modal-title">Mark Event as Completed</div>
              <button className="modal-close" onClick={()=>setShowCompleteModal(false)}>×</button>
            </div>
            <p style={{fontSize:14,color:'var(--text-muted)',marginBottom:12}}>
              Award Sweet Points to registered attendees. Enter their member usernames (comma-separated).
            </p>
            <div className="form-group">
              <label>Attendee Usernames (comma-separated)</label>
              <input className="input" value={attendees} onChange={e=>setAttendees(e.target.value)}
                placeholder="e.g. DM-4A9F, DM-7B2C, DM-9F4B" />
              <div style={{fontSize:12,color:'var(--text-muted)',marginTop:4}}>
                Each registered attendee will receive 200 Sweet Points.
              </div>
            </div>
            <div style={{display:'flex',gap:10,marginTop:16}}>
              <button className="btn btn-outline" style={{flex:1}} onClick={()=>setShowCompleteModal(false)}>Cancel</button>
              <button className="btn btn-primary" style={{flex:1}} onClick={confirmComplete}>
                Complete & Award Points
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
