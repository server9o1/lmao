import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MENU_ITEMS, TIER_CONFIG, calculatePoints, getTierFromCumulative, formatCurrency } from '../mockData';

export default function OrderEntry() {
  const { state, addToast, showPhoneMockup, triggerConfetti, placeOrder } = useApp();

  const [searchVal, setSearchVal]         = useState('');
  const [selectedMember, setSelectedMember] = useState(null);
  const [isGuest, setIsGuest]             = useState(false);
  const [cart, setCart]                   = useState({});   // itemId → qty
  const [payment, setPayment]             = useState('Cash');
  const [loading, setLoading]             = useState(false);
  const [showGuide, setShowGuide]         = useState(false);

  const filteredMembers = searchVal.length >= 2
    ? state.members.filter(m =>
        m.username.toLowerCase().includes(searchVal.toLowerCase()) ||
        m.name.toLowerCase().includes(searchVal.toLowerCase())
      )
    : [];

  const orderItems = Object.entries(cart)
    .filter(([,qty]) => qty > 0)
    .map(([id, qty]) => {
      const item = MENU_ITEMS.find(m => m.id === id);
      return { ...item, qty };
    });

  const orderTotal = orderItems.reduce((s, i) => s + i.price * i.qty, 0);

  const earnedPoints = selectedMember
    ? calculatePoints(orderTotal, selectedMember.tier)
    : 0;

  function addToCart(itemId) {
    setCart(prev => ({ ...prev, [itemId]: (prev[itemId] || 0) + 1 }));
  }
  function removeFromCart(itemId) {
    setCart(prev => {
      const n = { ...prev, [itemId]: (prev[itemId] || 1) - 1 };
      if (n[itemId] <= 0) delete n[itemId];
      return n;
    });
  }

  function selectMember(m) {
    setSelectedMember(m);
    setSearchVal(m.username);
    setIsGuest(false);
  }

  function handleGuestOrder() {
    setSelectedMember(null);
    setIsGuest(true);
    setSearchVal('');
  }

  async function handleConfirm() {
    if (orderItems.length === 0) { addToast('warning','Add at least one item to the order.'); return; }
    if (!selectedMember && !isGuest) { addToast('warning','Select a member or choose Guest Order.'); return; }

    setLoading(true);
    await new Promise(r => setTimeout(r, 900));

    const memberId   = selectedMember?.username || 'guest';
    const memberName = selectedMember?.name     || 'Guest';

    // Calculate tier upgrade before placing order
    let tierUpgradeInfo = null;
    if (selectedMember) {
      const pts  = calculatePoints(orderTotal, selectedMember.tier);
      const newCum = selectedMember.cumulativePoints + pts;
      const newTier = getTierFromCumulative(newCum);
      if (newTier !== selectedMember.tier) {
        tierUpgradeInfo = { name: selectedMember.name, newTier };
      }
    }

    placeOrder(memberId, memberName, orderItems, orderTotal, payment);
    setLoading(false);

    addToast('success', `✅ Order confirmed! ${formatCurrency(orderTotal)} received via ${payment}.`);

    if (selectedMember && earnedPoints > 0) {
      const newBal = selectedMember.redeemablePoints + earnedPoints;
      const newCum = selectedMember.cumulativePoints + earnedPoints;
      const newTier = getTierFromCumulative(newCum);
      setTimeout(() => {
        addToast('points', `⭐ ${selectedMember.name} earned ${earnedPoints} Sweet Points! Balance: ${newBal} pts • Tier: ${newTier}`);
      }, 400);
      setTimeout(() => {
        showPhoneMockup('wt02', selectedMember.name, {
          amount: orderTotal,
          points: earnedPoints,
          balance: newBal,
        });
      }, 700);
    }

    if (tierUpgradeInfo) {
      setTimeout(() => triggerConfetti(tierUpgradeInfo), 1200);
    }

    // Reset
    setCart({});
    // Update selected member from new state — clear and re-select if needed
    if (selectedMember) {
      const updated = state.members.find(m => m.username === selectedMember.username);
      if (updated) setSelectedMember({ ...updated,
        cumulativePoints: updated.cumulativePoints + earnedPoints,
        redeemablePoints: updated.redeemablePoints + earnedPoints,
        tier: getTierFromCumulative(updated.cumulativePoints + earnedPoints),
      });
    }
  }

  const tierConfig = selectedMember ? TIER_CONFIG[selectedMember.tier] : null;
  const birthdayThisMonth = selectedMember && selectedMember.birthdayMonth === new Date().getMonth() + 1;

  return (
    <div style={{ display:'grid', gridTemplateColumns:'340px 1fr', gap:16, height:'calc(100vh - 112px)' }}>

      {/* ── Left: Member Lookup ─────────────────────── */}
      <div style={{ display:'flex', flexDirection:'column', gap:12, overflowY:'auto' }}>
        <div className="card">
          <div className="card-title mb-3">Member Lookup</div>
          <input
            className="input input-lg"
            placeholder="Enter username or name (e.g. DM-7B2C)"
            value={searchVal}
            onChange={e => { setSearchVal(e.target.value); setSelectedMember(null); setIsGuest(false); }}
          />

          {filteredMembers.length > 0 && !selectedMember && (
            <div style={{
              border:'1.5px solid var(--border)', borderRadius:8, marginTop:8,
              maxHeight:200, overflowY:'auto', background:'var(--white)'
            }}>
              {filteredMembers.map(m => (
                <div
                  key={m.username}
                  onClick={() => selectMember(m)}
                  style={{
                    padding:'10px 14px', cursor:'pointer', borderBottom:'1px solid var(--border)',
                    display:'flex', alignItems:'center', gap:10,
                  }}
                  onMouseOver={e=>e.currentTarget.style.background='var(--bg)'}
                  onMouseOut={e=>e.currentTarget.style.background=''}
                >
                  <div style={{
                    width:32,height:32,borderRadius:'50%',
                    background:'var(--pink)',color:'#fff',
                    display:'flex',alignItems:'center',justifyContent:'center',
                    fontWeight:700,fontSize:14,flexShrink:0
                  }}>{m.name.charAt(0)}</div>
                  <div>
                    <div style={{fontWeight:600,fontSize:13}}>{m.name}</div>
                    <div style={{fontSize:12,color:'var(--text-muted)'}}>{m.username} · {m.tier}</div>
                  </div>
                </div>
              ))}
            </div>
          )}

          <button
            className="btn btn-outline mt-2"
            style={{width:'100%'}}
            onClick={handleGuestOrder}
          >
            👤 Guest Order (No Member)
          </button>
        </div>

        {/* Member profile card */}
        {selectedMember && (
          <div className="card" style={{borderTop:`4px solid ${TIER_CONFIG[selectedMember.tier].color}`}}>
            {birthdayThisMonth && (
              <div style={{
                background:'var(--pink-light)',borderRadius:8,padding:'8px 12px',
                marginBottom:12,fontSize:13,color:'var(--pink)',fontWeight:600
              }}>
                🎂 Birthday this month! Apply discount.
              </div>
            )}
            <div style={{display:'flex',gap:12,alignItems:'center',marginBottom:14}}>
              <div style={{
                width:48,height:48,borderRadius:'50%',
                background:TIER_CONFIG[selectedMember.tier].color,
                color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',
                fontWeight:800,fontSize:20
              }}>{selectedMember.name.charAt(0)}</div>
              <div>
                <div style={{fontWeight:700,fontSize:16}}>{selectedMember.name}</div>
                <div style={{fontSize:12,color:'var(--text-muted)'}}>{selectedMember.username}</div>
                <span className={`badge badge-${selectedMember.tier.toLowerCase()}`}>
                  {selectedMember.tier}
                </span>
              </div>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
              <div style={{background:'var(--bg)',borderRadius:8,padding:10,textAlign:'center'}}>
                <div style={{fontSize:11,color:'var(--text-muted)',fontWeight:600}}>REDEEMABLE</div>
                <div style={{fontSize:20,fontWeight:800,color:'var(--pink)'}}>{selectedMember.redeemablePoints}</div>
                <div style={{fontSize:11,color:'var(--text-muted)'}}>points</div>
              </div>
              <div style={{background:'var(--bg)',borderRadius:8,padding:10,textAlign:'center'}}>
                <div style={{fontSize:11,color:'var(--text-muted)',fontWeight:600}}>CUMULATIVE</div>
                <div style={{fontSize:20,fontWeight:800,color:TIER_CONFIG[selectedMember.tier].color}}>
                  {selectedMember.cumulativePoints}
                </div>
                <div style={{fontSize:11,color:'var(--text-muted)'}}>lifetime pts</div>
              </div>
            </div>
            <div style={{marginTop:10,fontSize:12,color:'var(--text-muted)'}}>
              Last 3 visits: {state.orders.filter(o=>o.memberId===selectedMember.username).slice(-3).map(o=>
                <span key={o.id} style={{marginLeft:6,background:'var(--bg)',borderRadius:4,padding:'1px 6px'}}>
                  {o.timestamp.split('T')[0]}
                </span>
              )}
            </div>
            {earnedPoints > 0 && orderTotal > 0 && (
              <div style={{
                marginTop:10,background:'var(--pink-light)',borderRadius:8,
                padding:'8px 12px',fontSize:12,color:'var(--pink)',fontWeight:600
              }}>
                ⭐ This order will earn {earnedPoints} pts
                ({tierConfig?.multiplier}× {selectedMember.tier} multiplier)
              </div>
            )}
          </div>
        )}

        {isGuest && (
          <div className="card" style={{borderTop:'4px solid var(--text-muted)'}}>
            <div style={{textAlign:'center',padding:'12px 0',color:'var(--text-muted)'}}>
              <div style={{fontSize:32}}>👤</div>
              <div style={{fontWeight:600,marginTop:8}}>Guest Order</div>
              <div style={{fontSize:12,marginTop:4}}>No points earned · No member linked</div>
            </div>
          </div>
        )}

        {/* Demo Guide */}
        <div className="card card-sm">
          <div
            style={{cursor:'pointer',display:'flex',justifyContent:'space-between',alignItems:'center'}}
            onClick={() => setShowGuide(g=>!g)}
          >
            <span style={{fontSize:13,fontWeight:600,color:'var(--text-muted)'}}>📖 Demo Script Guide</span>
            <span style={{fontSize:12,color:'var(--text-muted)'}}>{showGuide ? '▲' : '▼'}</span>
          </div>
          {showGuide && (
            <div className="demo-guide" style={{marginTop:10}}>
              <h4>🎬 Live Demo — Tier Upgrade Flow</h4>
              <p>
                Enter <code>DM-7B2C</code> (Nusrat Jahan, Silver, 980 pts cumulative).<br/>
                Add <code>2× Dreamy Waffle</code> (BDT 598).<br/>
                Confirm with <code>bKash</code>.<br/>
                She earns <code>floor(598 × 1.2) = 717 pts</code>, taking her cumulative to 1,697 — crossing the 1,500 Gold threshold.<br/>
                Watch the 🎉 <strong>TIER UPGRADE</strong> animation fire!
              </p>
            </div>
          )}
        </div>
      </div>

      {/* ── Right: Menu + Order Summary ─────────────── */}
      <div style={{ display:'flex', flexDirection:'column', gap:12, overflowY:'auto' }}>
        <div className="card">
          <div className="card-title mb-3">Menu</div>
          <div className="menu-grid">
            {MENU_ITEMS.map(item => (
              <div
                key={item.id}
                className={`menu-card ${cart[item.id] ? 'selected' : ''}`}
                onClick={() => addToCart(item.id)}
              >
                {cart[item.id] > 0 && (
                  <div className="qty-badge">{cart[item.id]}</div>
                )}
                <div style={{
                  width:52,height:52,borderRadius:12,
                  background:item.color,
                  display:'flex',alignItems:'center',justifyContent:'center',
                  fontSize:28
                }}>{item.emoji}</div>
                <div className="name">{item.name}</div>
                <div className="price">{formatCurrency(item.price)}</div>
                {cart[item.id] > 0 && (
                  <button
                    className="btn btn-outline btn-sm"
                    style={{marginTop:4,width:'100%'}}
                    onClick={e => { e.stopPropagation(); removeFromCart(item.id); }}
                  >− Remove</button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Order Summary Bar */}
        <div className="card" style={{position:'sticky',bottom:0}}>
          <div className="card-title mb-3">Order Summary</div>
          {orderItems.length === 0 ? (
            <div style={{color:'var(--text-muted)',fontSize:13,padding:'8px 0'}}>
              Tap menu items above to add them to the order.
            </div>
          ) : (
            <div style={{marginBottom:12}}>
              {orderItems.map(item => (
                <div key={item.id} style={{
                  display:'flex',justifyContent:'space-between',alignItems:'center',
                  padding:'6px 0',borderBottom:'1px solid var(--border)',fontSize:14
                }}>
                  <span>{item.emoji} {item.name} ×{item.qty}</span>
                  <span style={{fontWeight:600}}>{formatCurrency(item.price * item.qty)}</span>
                </div>
              ))}
              <div style={{
                display:'flex',justifyContent:'space-between',
                padding:'10px 0 0',fontSize:16,fontWeight:800
              }}>
                <span>Total</span>
                <span style={{color:'var(--pink)'}}>{formatCurrency(orderTotal)}</span>
              </div>
            </div>
          )}

          <div style={{marginBottom:12}}>
            <div className="section-label">Payment Method</div>
            <div className="payment-toggle">
              {['Cash','bKash','Nagad'].map(m => (
                <button
                  key={m}
                  className={`payment-btn ${payment === m ? 'active' : ''}`}
                  onClick={() => setPayment(m)}
                >
                  {m === 'Cash' ? '💵' : m === 'bKash' ? '📱' : '💳'} {m}
                </button>
              ))}
            </div>
          </div>

          <button
            className="btn btn-primary btn-lg"
            style={{width:'100%'}}
            onClick={handleConfirm}
            disabled={loading || orderItems.length === 0}
          >
            {loading ? (
              <><div className="loading-spinner" /> Processing order...</>
            ) : (
              `Confirm Order — ${formatCurrency(orderTotal)}`
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
