import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { WHATSAPP_TEMPLATES } from '../mockData';

const BRANCHES = [
  {
    name:'Kumarpara, Sylhet', status:'active', year:'Current',
    description:'Flagship branch — operational since 2024',
    icon:'🏪',
  },
  {
    name:'Amber Khana, Sylhet', status:'planned', year:'Year 4',
    description:'Second Sylhet location — target 2028',
    icon:'🏗️',
  },
  {
    name:'Dhaka — Dhanmondi', status:'planned', year:'Year 5',
    description:'Dhaka expansion — target 2029',
    icon:'🌆',
  },
];

export default function Settings() {
  const { state, dispatch, addToast, showPhoneMockup } = useApp();

  const [showResetModal, setShowResetModal] = useState(false);
  const [branchModal, setBranchModal]       = useState(null);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [templateMember, setTemplateMember] = useState('DM-4A9F');

  const cfg = state.systemConfig;

  function handleConfigChange(key, val) {
    dispatch({ type:'UPDATE_CONFIG', config:{ [key]:isNaN(val)?val:Number(val) } });
  }

  function handleReset() {
    dispatch({ type:'RESET_DEMO' });
    addToast('success','Demo data has been reset to initial state.');
    setShowResetModal(false);
  }

  const previewMember = state.members.find(m=>m.username===templateMember) || state.members[0];

  return (
    <div>
      {/* Branch Selector */}
      <div className="card mb-4">
        <div className="card-header">
          <div className="card-title">🏢 Branch Network</div>
          <span className="badge badge-success">1 Active · 2 Planned</span>
        </div>
        <div className="grid-3" style={{gap:12}}>
          {BRANCHES.map(b => (
            <div
              key={b.name}
              onClick={() => b.status !== 'active' && setBranchModal(b)}
              style={{
                borderRadius:12,
                border:`2px solid ${b.status==='active'?'var(--teal)':'var(--border)'}`,
                padding:16,cursor:b.status!=='active'?'pointer':'default',
                background:b.status==='active'?'var(--teal-light)':'var(--white)',
                position:'relative',opacity:b.status==='active'?1:0.75,
                transition:'all 0.2s',
              }}
              onMouseOver={e=>{ if(b.status!=='active') e.currentTarget.style.borderColor='var(--pink)'; }}
              onMouseOut={e=>{ if(b.status!=='active') e.currentTarget.style.borderColor='var(--border)'; }}
            >
              {b.status === 'active' && (
                <div style={{
                  position:'absolute',top:10,right:10,
                  background:'var(--teal)',color:'#fff',
                  borderRadius:20,padding:'2px 10px',fontSize:11,fontWeight:700
                }}>✓ CURRENT</div>
              )}
              {b.status === 'planned' && (
                <div style={{
                  position:'absolute',top:10,right:10,
                  background:'var(--bg)',color:'var(--text-muted)',
                  borderRadius:20,padding:'2px 10px',fontSize:11,fontWeight:700
                }}>⏳ {b.year}</div>
              )}
              <div style={{fontSize:32,marginBottom:8}}>{b.icon}</div>
              <div style={{fontWeight:700,fontSize:15,marginBottom:4}}>{b.name}</div>
              <div style={{fontSize:12,color:'var(--text-muted)'}}>{b.description}</div>
              {b.status === 'planned' && (
                <div style={{
                  marginTop:10,fontSize:12,color:'var(--text-muted)',fontStyle:'italic'
                }}>
                  Click to see branch readiness
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* System Configuration */}
      <div className="grid-2" style={{gap:16,marginBottom:16}}>
        <div className="card">
          <div className="card-header">
            <div className="card-title">⚙️ System Configuration</div>
            <span className="badge badge-info">Live — affects Financial</span>
          </div>
          <div className="form-group">
            <label>Break-Even Orders/Day</label>
            <input className="input" type="number" value={cfg.breakEvenOrders}
              onChange={e=>handleConfigChange('breakEvenOrders',e.target.value)} />
          </div>
          <div className="form-group">
            <label>Fixed Monthly Costs (BDT)</label>
            <input className="input" type="number" value={cfg.fixedMonthlyCosts}
              onChange={e=>handleConfigChange('fixedMonthlyCosts',e.target.value)} />
          </div>
          <div className="form-group">
            <label>Variable Cost % (e.g. 38)</label>
            <input className="input" type="number" value={cfg.variableCostPercent}
              onChange={e=>handleConfigChange('variableCostPercent',e.target.value)} />
          </div>
          <div className="form-group">
            <label>Avg Selling Price (BDT)</label>
            <input className="input" type="number" value={cfg.avgSellingPrice}
              onChange={e=>handleConfigChange('avgSellingPrice',e.target.value)} />
          </div>
          <div style={{background:'var(--bg)',borderRadius:8,padding:12,fontSize:13}}>
            <div style={{fontWeight:600,marginBottom:4}}>Live Recalculation:</div>
            <div style={{color:'var(--text-muted)'}}>
              Contribution: BDT {Math.round(cfg.avgSellingPrice*(1-cfg.variableCostPercent/100))} ·
              Break-even: {Math.ceil((cfg.fixedMonthlyCosts*12)/(cfg.avgSellingPrice*(1-cfg.variableCostPercent/100))/365)} orders/day
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-title mb-3">⭐ Sweet Points — Tier Earn Rates</div>
          {Object.entries(cfg.earnRates).map(([tier, rate]) => (
            <div key={tier} className="form-group">
              <label>{tier} Tier Multiplier</label>
              <div style={{display:'flex',alignItems:'center',gap:10}}>
                <input className="input" type="number" step="0.1" value={rate}
                  onChange={e=>handleConfigChange('earnRates',{...cfg.earnRates,[tier]:parseFloat(e.target.value)||1})}
                  style={{width:80}}/>
                <span style={{fontSize:13,color:'var(--text-muted)'}}>
                  × (1 pt per BDT × {rate} = {rate} pts per BDT)
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* WhatsApp Templates */}
      <div className="card mb-4">
        <div className="card-header">
          <div className="card-title">📱 WhatsApp Notification Templates</div>
          <div style={{display:'flex',alignItems:'center',gap:10}}>
            <span style={{fontSize:12,color:'var(--text-muted)'}}>Preview member:</span>
            <select className="select" style={{width:180}} value={templateMember} onChange={e=>setTemplateMember(e.target.value)}>
              {state.members.map(m=><option key={m.username} value={m.username}>{m.name}</option>)}
            </select>
          </div>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8}}>
          {WHATSAPP_TEMPLATES.map(t => (
            <div
              key={t.id}
              onClick={() => { setSelectedTemplate(t); showPhoneMockup(t.id, previewMember?.name, { username:previewMember?.username, amount:350, points:420, redeemableBalance:900, reward:'Free Topping', date:'Sat 19 Apr', time:'6:00 PM', package:'Grand Celebration', theme:'Strawberry', guests:6, advance:4250, balance:4250 }); }}
              style={{
                padding:12,borderRadius:8,cursor:'pointer',
                border:`1.5px solid ${selectedTemplate?.id===t.id?'var(--pink)':'var(--border)'}`,
                background:selectedTemplate?.id===t.id?'var(--pink-light)':'var(--white)',
                transition:'all 0.2s',
              }}
              onMouseOver={e=>e.currentTarget.style.borderColor='var(--pink)'}
              onMouseOut={e=>{ if(selectedTemplate?.id!==t.id) e.currentTarget.style.borderColor='var(--border)'; }}
            >
              <div style={{fontSize:11,color:'var(--text-muted)',fontWeight:700,textTransform:'uppercase',marginBottom:4}}>
                {t.category}
              </div>
              <div style={{fontWeight:600,fontSize:13,marginBottom:4}}>{t.name}</div>
              <div style={{fontSize:11,color:'var(--text-muted)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                {t.body.slice(0,60)}...
              </div>
              <div style={{fontSize:11,color:'var(--pink)',marginTop:4,fontWeight:600}}>
                Click to preview →
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Demo Reset */}
      <div className="card" style={{borderTop:'4px solid #ef5350'}}>
        <div className="card-header">
          <div>
            <div className="card-title" style={{color:'#ef5350'}}>⚠️ Demo Reset</div>
            <div className="card-subtitle">For professor demonstrations — restore all data to initial seed state</div>
          </div>
          <button className="btn btn-danger" onClick={()=>setShowResetModal(true)}>
            Reset Demo Data
          </button>
        </div>
        <div style={{fontSize:13,color:'var(--text-muted)',background:'#FFEBEE',padding:12,borderRadius:8}}>
          This will clear all orders placed during the demo, restore all member profiles to seed data,
          reset all activity feeds and financial figures, and restore wall of fame posts to initial state.
          The system will return exactly to its pre-demo condition.
        </div>
      </div>

      {/* Branch Modal */}
      {branchModal && (
        <div className="modal-overlay" onClick={()=>setBranchModal(null)}>
          <div className="modal" onClick={e=>e.stopPropagation()}>
            <div className="modal-header">
              <div className="modal-title">{branchModal.icon} {branchModal.name}</div>
              <button className="modal-close" onClick={()=>setBranchModal(null)}>×</button>
            </div>
            <div style={{
              background:'var(--bg)',borderRadius:8,padding:16,marginBottom:16,
              textAlign:'center'
            }}>
              <div style={{fontSize:14,color:'var(--text-muted)'}}>Planned for</div>
              <div style={{fontSize:24,fontWeight:800,color:'var(--pink)',margin:'4px 0'}}>{branchModal.year}</div>
              <div style={{fontSize:13,color:'var(--text-muted)'}}>{branchModal.description}</div>
            </div>
            <p style={{fontSize:14,lineHeight:1.7,color:'var(--text-muted)',marginBottom:16}}>
              This branch is planned for <strong>{branchModal.year}</strong>. All IS infrastructure is pre-configured and will activate when the branch goes live.
            </p>
            <div style={{display:'flex',flexDirection:'column',gap:8,marginBottom:16}}>
              {[
                '✅ Member Sweet Points automatically apply here',
                '✅ No separate registration required for members',
                '✅ Shared financial dashboard across all branches',
                '✅ Unified WhatsApp notification system',
                '✅ Centralised CRM — every customer visible',
                '⏳ Physical setup required before activation',
              ].map(item => (
                <div key={item} style={{fontSize:13,padding:'6px 10px',background:item.startsWith('✅')?'var(--teal-light)':'var(--bg)',borderRadius:6,color:item.startsWith('✅')?'var(--teal-dark)':'var(--text-muted)'}}>
                  {item}
                </div>
              ))}
            </div>
            <button className="btn btn-primary" style={{width:'100%'}} onClick={()=>setBranchModal(null)}>
              Understood
            </button>
          </div>
        </div>
      )}

      {/* Reset Confirm Modal */}
      {showResetModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <div className="modal-title" style={{color:'#ef5350'}}>⚠️ Confirm Demo Reset</div>
              <button className="modal-close" onClick={()=>setShowResetModal(false)}>×</button>
            </div>
            <p style={{fontSize:14,lineHeight:1.7,color:'var(--text-muted)',marginBottom:20}}>
              Are you sure you want to reset all demo data? This will:
              <br/>• Clear all orders placed during this demo session
              <br/>• Restore all member profiles to seed data
              <br/>• Reset activity feeds and financial figures
              <br/>This cannot be undone.
            </p>
            <div style={{display:'flex',gap:10}}>
              <button className="btn btn-outline" style={{flex:1}} onClick={()=>setShowResetModal(false)}>
                Cancel
              </button>
              <button className="btn btn-danger" style={{flex:1}} onClick={handleReset}>
                Yes, Reset Everything
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
