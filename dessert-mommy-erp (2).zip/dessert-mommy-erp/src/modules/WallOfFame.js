import React, { useState } from 'react';
import { useApp } from '../context/AppContext';

const PLATFORMS = ['Instagram','Facebook','TikTok'];
const PLATFORM_COLORS = {
  Instagram: { bg:'#FCE4EC', color:'#AD1457', icon:'📸' },
  Facebook:  { bg:'#E3F2FD', color:'#1565C0', icon:'👤' },
  TikTok:    { bg:'#F3E5F5', color:'#6A1B9A', icon:'🎵' },
};

function PlatformBadge({ platform }) {
  const cfg = PLATFORM_COLORS[platform] || { bg:'#F5F5F5', color:'#333', icon:'🌐' };
  return (
    <span className={`platform-badge platform-${platform.toLowerCase()}`} style={{background:cfg.bg,color:cfg.color}}>
      {cfg.icon} {platform}
    </span>
  );
}

export default function WallOfFame() {
  const { state, dispatch, addToast, showPhoneMockup } = useApp();

  const [showTVPreview, setShowTVPreview]   = useState(false);
  const [tvSlide, setTvSlide]               = useState(0);
  const [showAddForm, setShowAddForm]       = useState(false);
  const [rejectId, setRejectId]             = useState(null);
  const [rejectReason, setRejectReason]     = useState('');
  const [newPost, setNewPost]               = useState({ platform:'Instagram', memberId:'', url:'', date:'' });

  const pending  = state.wallPosts.filter(p => p.status === 'pending');
  const approved = state.wallPosts.filter(p => p.status === 'approved');
  const rejected = state.wallPosts.filter(p => p.status === 'rejected');

  function handleApprove(post) {
    dispatch({ type:'APPROVE_WALL_POST', id:post.id });
    addToast('success', `✅ Post approved! 50 Sweet Points awarded to ${post.memberName}.`);
    showPhoneMockup('wt09', post.memberName);
  }

  function handleReject(post) {
    setRejectId(post.id);
  }

  function confirmReject() {
    dispatch({ type:'REJECT_WALL_POST', id:rejectId, reason:rejectReason });
    addToast('info', 'Post rejected.');
    setRejectId(null); setRejectReason('');
  }

  function handleAddPost() {
    if (!newPost.memberId || !newPost.url || !newPost.date) {
      addToast('warning','Fill all fields.'); return;
    }
    const member = state.members.find(m => m.username === newPost.memberId || m.name.toLowerCase() === newPost.memberId.toLowerCase());
    dispatch({
      type:'ADD_WALL_POST',
      post:{ ...newPost, memberName:member?.name || newPost.memberId, date:newPost.date }
    });
    addToast('success','Post added to Pending queue.');
    setShowAddForm(false);
    setNewPost({ platform:'Instagram', memberId:'', url:'', date:'' });
  }

  // TV slideshow effect
  React.useEffect(() => {
    if (!showTVPreview || approved.length === 0) return;
    const t = setInterval(() => setTvSlide(s => (s+1) % approved.length), 3000);
    return () => clearInterval(t);
  }, [showTVPreview, approved.length]);

  const PostCard = ({ post, col }) => (
    <div className="kanban-card">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}}>
        <PlatformBadge platform={post.platform} />
        {col === 'approved' && <span className="badge badge-success">+50 pts</span>}
        {col === 'rejected' && <span className="badge badge-error">Rejected</span>}
      </div>
      <div style={{fontWeight:600,fontSize:14,marginBottom:2}}>{post.memberName}</div>
      <div style={{fontSize:11,color:'var(--text-muted)',marginBottom:6}}>{post.memberId}</div>
      <div style={{fontSize:11,color:'var(--text-muted)',marginBottom:6}}>{post.date}</div>
      <div style={{
        fontSize:11,color:'var(--pink)',wordBreak:'break-all',
        background:'var(--pink-light)',borderRadius:4,padding:'2px 6px',marginBottom:10,
        overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'
      }}>
        🔗 {post.url}
      </div>
      {post.reason && (
        <div style={{fontSize:11,color:'var(--text-muted)',fontStyle:'italic',marginBottom:8}}>
          Reason: {post.reason}
        </div>
      )}
      {col === 'pending' && (
        <div style={{display:'flex',gap:6}}>
          <button
            className="btn btn-secondary btn-sm"
            style={{flex:1}}
            onClick={() => handleApprove(post)}
          >✅ Approve</button>
          <button
            className="btn btn-danger btn-sm"
            style={{flex:1}}
            onClick={() => handleReject(post)}
          >✗ Reject</button>
        </div>
      )}
    </div>
  );

  const today = new Date().toISOString().split('T')[0];

  return (
    <div>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}}>
        <div>
          <div style={{fontWeight:700,fontSize:16}}>Wall of Fame Content Queue</div>
          <div style={{fontSize:13,color:'var(--text-muted)'}}>
            {pending.length} pending · {approved.length} approved · {rejected.length} rejected
          </div>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button className="btn btn-outline btn-sm" onClick={() => setShowTVPreview(true)}>
            📺 TV Preview
          </button>
          <button className="btn btn-primary btn-sm" onClick={() => setShowAddForm(true)}>
            + Add Post
          </button>
        </div>
      </div>

      {/* Kanban Board */}
      <div className="kanban-wrap">
        {/* Pending Column */}
        <div className="kanban-col">
          <div className="kanban-col-header">
            <div className="kanban-col-title" style={{color:'#FF9800'}}>⏳ Pending Review</div>
            <span className="kanban-col-count" style={{background:'#FFF3E0',color:'#E65100'}}>{pending.length}</span>
          </div>
          {pending.length === 0 ? (
            <div className="empty-state" style={{padding:'30px 0'}}>
              <div className="icon">📭</div>
              <p>No pending posts</p>
            </div>
          ) : (
            pending.map(p => <PostCard key={p.id} post={p} col="pending" />)
          )}
        </div>

        {/* Approved Column */}
        <div className="kanban-col">
          <div className="kanban-col-header">
            <div className="kanban-col-title" style={{color:'var(--teal)'}}>✅ Approved & Active</div>
            <span className="kanban-col-count" style={{background:'var(--teal-light)',color:'var(--teal-dark)'}}>{approved.length}</span>
          </div>
          {approved.length === 0 ? (
            <div className="empty-state" style={{padding:'30px 0'}}>
              <div className="icon">🌟</div>
              <p>No approved posts yet</p>
            </div>
          ) : (
            approved.map(p => <PostCard key={p.id} post={p} col="approved" />)
          )}
        </div>

        {/* Rejected Column */}
        <div className="kanban-col">
          <div className="kanban-col-header">
            <div className="kanban-col-title" style={{color:'#ef5350'}}>✗ Rejected</div>
            <span className="kanban-col-count" style={{background:'#FFEBEE',color:'#C62828'}}>{rejected.length}</span>
          </div>
          {rejected.length === 0 ? (
            <div className="empty-state" style={{padding:'30px 0'}}>
              <div className="icon">✓</div>
              <p>No rejections</p>
            </div>
          ) : (
            rejected.map(p => <PostCard key={p.id} post={p} col="rejected" />)
          )}
        </div>
      </div>

      {/* TV Preview Modal */}
      {showTVPreview && approved.length > 0 && (
        <div className="tv-overlay" onClick={() => setShowTVPreview(false)}>
          <div style={{
            width:'100%',padding:'0 40px',maxWidth:1000,
            textAlign:'center',
          }} onClick={e=>e.stopPropagation()}>
            {/* TV Header */}
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:40}}>
              <div style={{color:'var(--pink)',fontSize:24,fontWeight:800,fontFamily:'Poppins,sans-serif'}}>
                Dessert Mommy
              </div>
              <div style={{color:'rgba(255,255,255,0.4)',fontSize:14}}>
                Wall of Fame — Kumarpara, Sylhet
              </div>
            </div>

            {/* Slide */}
            {(() => {
              const post = approved[tvSlide % approved.length];
              if (!post) return null;
              const pcfg = PLATFORM_COLORS[post.platform] || {};
              return (
                <div className="tv-slide">
                  <div style={{fontSize:14,color:'rgba(255,255,255,0.5)',marginBottom:16,letterSpacing:2,textTransform:'uppercase'}}>
                    {pcfg.icon} {post.platform} · Community Highlight
                  </div>
                  <div style={{
                    width:200,height:200,borderRadius:'50%',
                    background:`linear-gradient(135deg,var(--pink),var(--teal))`,
                    display:'flex',alignItems:'center',justifyContent:'center',
                    margin:'0 auto 24px',fontSize:72
                  }}>
                    {post.memberName.charAt(0)}
                  </div>
                  <div style={{
                    fontSize:48,fontWeight:800,color:'var(--teal)',
                    fontFamily:'Poppins,sans-serif',marginBottom:8
                  }}>
                    {post.memberName}
                  </div>
                  <div style={{color:'rgba(255,255,255,0.6)',fontSize:18,marginBottom:24}}>
                    {post.memberId}
                  </div>
                  <div style={{
                    color:'rgba(255,255,255,0.4)',fontSize:14,
                    borderTop:'1px solid rgba(255,255,255,0.1)',
                    paddingTop:20,marginTop:20
                  }}>
                    Share your Dessert Mommy moment — tag <strong style={{color:'var(--pink)'}}>#DessertMommy</strong>
                  </div>
                  <div style={{display:'flex',justifyContent:'center',gap:8,marginTop:20}}>
                    {approved.map((_,i) => (
                      <div key={i} style={{
                        width:8,height:8,borderRadius:'50%',
                        background:i===tvSlide%approved.length?'var(--pink)':'rgba(255,255,255,0.2)'
                      }}/>
                    ))}
                  </div>
                </div>
              );
            })()}

            <button
              className="btn btn-outline mt-4"
              style={{color:'#fff',borderColor:'rgba(255,255,255,0.3)',marginTop:30}}
              onClick={() => setShowTVPreview(false)}
            >
              Close Preview
            </button>
          </div>
        </div>
      )}

      {/* Reject Modal */}
      {rejectId && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <div className="modal-title">Reject Post</div>
              <button className="modal-close" onClick={()=>setRejectId(null)}>×</button>
            </div>
            <div className="form-group">
              <label>Rejection Reason (optional)</label>
              <input className="input" value={rejectReason} onChange={e=>setRejectReason(e.target.value)}
                placeholder="e.g. Did not tag #DessertMommy" />
            </div>
            <div style={{display:'flex',gap:10,marginTop:16}}>
              <button className="btn btn-outline" style={{flex:1}} onClick={()=>setRejectId(null)}>Cancel</button>
              <button className="btn btn-danger" style={{flex:1}} onClick={confirmReject}>Reject Post</button>
            </div>
          </div>
        </div>
      )}

      {/* Add Post Form */}
      {showAddForm && (
        <div className="modal-overlay" onClick={()=>setShowAddForm(false)}>
          <div className="modal" onClick={e=>e.stopPropagation()}>
            <div className="modal-header">
              <div className="modal-title">Add Post Manually</div>
              <button className="modal-close" onClick={()=>setShowAddForm(false)}>×</button>
            </div>
            <div className="form-group">
              <label>Platform</label>
              <select className="select" value={newPost.platform} onChange={e=>setNewPost(p=>({...p,platform:e.target.value}))}>
                {PLATFORMS.map(pl => <option key={pl}>{pl}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label>Member Username or Name</label>
              <input className="input" value={newPost.memberId} onChange={e=>setNewPost(p=>({...p,memberId:e.target.value}))}
                placeholder="e.g. DM-4A9F" />
            </div>
            <div className="form-group">
              <label>Post URL</label>
              <input className="input" value={newPost.url} onChange={e=>setNewPost(p=>({...p,url:e.target.value}))}
                placeholder="https://..." />
            </div>
            <div className="form-group">
              <label>Date</label>
              <input className="input" type="date" value={newPost.date} max={today}
                onChange={e=>setNewPost(p=>({...p,date:e.target.value}))} />
            </div>
            <div style={{display:'flex',gap:10,marginTop:16}}>
              <button className="btn btn-outline" style={{flex:1}} onClick={()=>setShowAddForm(false)}>Cancel</button>
              <button className="btn btn-primary" style={{flex:1}} onClick={handleAddPost}>Add to Queue</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
