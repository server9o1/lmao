import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell, ResponsiveContainer } from 'recharts';
import { useApp } from '../context/AppContext';
import { MENU_ITEMS, MOOD_FIXER_LETTERS, getTimeOfDay, formatCurrency, calculatePoints } from '../mockData';

const SPIN_DURATION = 1500;

export default function MysteryBox() {
  const { state, dispatch, addToast, showPhoneMockup } = useApp();

  const [memberInput, setMemberInput]         = useState('');
  const [selectedMember, setSelectedMember]   = useState(null);
  const [isSpinning, setIsSpinning]           = useState(false);
  const [revealedItem, setRevealedItem]       = useState(null);
  const [slotText, setSlotText]               = useState('?');
  const [staffView, setStaffView]             = useState(true);

  function lookupMember(val) {
    const m = state.members.find(mb => mb.username === val || mb.name.toLowerCase() === val.toLowerCase());
    setSelectedMember(m || null);
  }

  async function spin() {
    if (!selectedMember) { addToast('warning','Enter a member username first.'); return; }
    if (isSpinning) return;

    setIsSpinning(true);
    setRevealedItem(null);

    // Slot machine animation
    const interval = setInterval(() => {
      const randomItem = MENU_ITEMS[Math.floor(Math.random() * MENU_ITEMS.length)];
      setSlotText(`${randomItem.emoji} ${randomItem.name}`);
    }, 80);

    await new Promise(r => setTimeout(r, SPIN_DURATION));
    clearInterval(interval);

    // Final selection
    const selected = MENU_ITEMS[Math.floor(Math.random() * MENU_ITEMS.length)];
    setSlotText(`${selected.emoji} ${selected.name}`);
    setRevealedItem(selected);
    setIsSpinning(false);

    // Dispatch to state
    dispatch({
      type: 'SPIN_MYSTERY_BOX',
      memberId: selectedMember.username,
      memberName: selectedMember.name,
      selectedItem: selected,
    });

    const earned = calculatePoints(249, selectedMember.tier);
    addToast('success', `🎁 Mystery Box revealed for ${selectedMember.name}!`);
    setTimeout(() => {
      addToast('points', `⭐ ${earned} pts earned — ${selectedMember.name}`);
    }, 400);

    showPhoneMockup('wt11', selectedMember.name);
  }

  const chartData = state.mysteryHistory.map(h => ({
    name: h.itemName.split(' ').slice(0,2).join(' '),
    count: h.count,
    fill: MENU_ITEMS.find(m=>m.id===h.itemId)?.color || 'var(--pink)',
  }));

  const timeOfDay = getTimeOfDay();
  const moodLetter = MOOD_FIXER_LETTERS[timeOfDay];

  return (
    <div>
      <div className="grid-2" style={{gap:16,alignItems:'start'}}>
        {/* Main Mystery Box Interface */}
        <div>
          <div className="card" style={{background:'var(--navy)',border:'none'}}>
            <div style={{textAlign:'center',marginBottom:20}}>
              <h2 style={{color:'var(--white)',fontSize:20,fontWeight:800}}>Mystery Dessert Box</h2>
              <p style={{color:'rgba(255,255,255,0.5)',fontSize:14}}>{formatCurrency(249)} · Surprise selected for you</p>
            </div>

            {/* Member input */}
            <div style={{marginBottom:20}}>
              <input
                className="input input-lg"
                style={{background:'rgba(255,255,255,0.05)',border:'1.5px solid rgba(255,255,255,0.15)',color:'#fff'}}
                placeholder="Enter member username (e.g. DM-4A9F)"
                value={memberInput}
                onChange={e => { setMemberInput(e.target.value); lookupMember(e.target.value); }}
              />
              {selectedMember && (
                <div style={{
                  marginTop:8,padding:'8px 12px',background:'rgba(0,137,123,0.15)',
                  borderRadius:8,border:'1px solid var(--teal)',color:'var(--teal)',fontSize:13
                }}>
                  ✓ {selectedMember.name} · {selectedMember.tier} · {selectedMember.redeemablePoints} pts
                </div>
              )}
            </div>

            {/* Mystery Box Icon */}
            <div className="mystery-box-wrap" style={{padding:'20px 0'}}>
              <div
                className={`mystery-box-icon ${isSpinning?'spinning':''}`}
                onClick={spin}
              >
                {revealedItem ? revealedItem.emoji : '🎁'}
              </div>

              {/* Slot machine display */}
              <div className="slot-machine" style={{color:revealedItem?'var(--teal)':'rgba(255,255,255,0.7)'}}>
                {isSpinning ? slotText : revealedItem ? `${revealedItem.emoji} ${revealedItem.name}` : '???'}
              </div>

              {/* Staff/Customer toggle */}
              <div style={{display:'flex',alignItems:'center',gap:10}}>
                <span style={{fontSize:12,color:'rgba(255,255,255,0.5)'}}>Customer View</span>
                <div
                  onClick={() => setStaffView(s=>!s)}
                  style={{
                    width:44,height:24,borderRadius:12,cursor:'pointer',
                    background:staffView?'var(--teal)':'rgba(255,255,255,0.2)',
                    position:'relative',transition:'background 0.3s',
                  }}
                >
                  <div style={{
                    position:'absolute',top:2,left:staffView?22:2,
                    width:20,height:20,borderRadius:'50%',background:'#fff',
                    transition:'left 0.3s',
                  }}/>
                </div>
                <span style={{fontSize:12,color:'rgba(255,255,255,0.5)'}}>Staff View</span>
              </div>
            </div>

            {/* Customer blur overlay */}
            {revealedItem && !staffView && (
              <div style={{
                background:'rgba(26,26,46,0.9)',borderRadius:12,padding:30,
                textAlign:'center',marginTop:-20,backdropFilter:'blur(10px)'
              }}>
                <div style={{fontSize:40}}>🎉</div>
                <div style={{color:'#fff',fontSize:18,fontWeight:700,marginTop:8}}>
                  Your surprise is being prepared!
                </div>
                <div style={{color:'rgba(255,255,255,0.5)',fontSize:13,marginTop:4}}>
                  We'll serve it fresh in just a moment 💕
                </div>
              </div>
            )}

            {/* Reveal button */}
            <button
              className="btn btn-primary btn-lg"
              style={{width:'100%',marginTop:16,fontSize:16,fontWeight:800}}
              onClick={spin}
              disabled={isSpinning || !selectedMember}
            >
              {isSpinning ? (
                <><div className="loading-spinner"/> Revealing...</>
              ) : (
                '🎁 Reveal Today\'s Mystery'
              )}
            </button>
          </div>

          {/* Mood Fixer Letter */}
          {revealedItem && (
            <div className="card mt-4">
              <div className="mood-letter-header">
                💌 Mood Fixer Letter — {timeOfDay.charAt(0).toUpperCase()+timeOfDay.slice(1)}
              </div>
              <div className="mood-letter">
                {moodLetter}
              </div>
            </div>
          )}
        </div>

        <div style={{display:'flex',flexDirection:'column',gap:16}}>
          {/* Revealed item card */}
          {revealedItem && staffView && (
            <div className="card" style={{borderTop:`4px solid ${revealedItem.color}`}}>
              <div className="mystery-result">
                <div style={{fontSize:12,color:'var(--text-muted)',fontWeight:600,textTransform:'uppercase',letterSpacing:1,marginBottom:12}}>
                  Today's Selection
                </div>
                <div className="item-emoji">{revealedItem.emoji}</div>
                <div className="item-name mt-2">{revealedItem.name}</div>
                <div style={{
                  marginTop:8,fontSize:18,fontWeight:700,color:'var(--pink)'
                }}>{formatCurrency(249)}</div>
                <div style={{
                  marginTop:10,padding:'10px 20px',background:'var(--teal-light)',
                  borderRadius:8,color:'var(--teal-dark)',fontSize:13,fontWeight:600
                }}>
                  Prepare: {revealedItem.name}
                </div>
              </div>
            </div>
          )}

          {/* Fairness Chart */}
          <div className="card">
            <div className="card-header">
              <div className="card-title">Selection Fairness — All Time</div>
              <span className="badge badge-success">Equal Distribution</span>
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={chartData} layout="vertical" margin={{left:10,right:20,top:0,bottom:0}}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" tick={{fontSize:12}} />
                <YAxis dataKey="name" type="category" tick={{fontSize:11}} width={100} />
                <Tooltip />
                <Bar dataKey="count" radius={[0,4,4,0]}>
                  {chartData.map((e,i) => <Cell key={i} fill={e.fill} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <div style={{fontSize:12,color:'var(--text-muted)',textAlign:'center',marginTop:8}}>
              Total mystery boxes sold: {state.mysteryHistory.reduce((s,h)=>s+h.count,0)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
