import React from 'react';
import { useApp } from '../context/AppContext';

const TOAST_ICONS = {
  success: '✅',
  points:  '⭐',
  warning: '⚠️',
  error:   '❌',
  info:    'ℹ️',
};

export default function ToastContainer() {
  const { state, dispatch } = useApp();

  return (
    <div className="toast-container">
      {state.toasts.map(t => (
        <div key={t.id} className={`toast toast-${t.toastType || 'success'}`}>
          <span className="toast-icon">{TOAST_ICONS[t.toastType] || '✅'}</span>
          <span className="toast-msg">{t.message}</span>
          <span
            className="toast-close"
            onClick={() => dispatch({ type:'REMOVE_TOAST', id:t.id })}
          >×</span>
        </div>
      ))}
    </div>
  );
}
