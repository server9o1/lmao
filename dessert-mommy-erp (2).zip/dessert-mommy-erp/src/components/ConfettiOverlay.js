import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { useApp } from '../context/AppContext';

const TIER_COLORS = {
  Silver:   ['#757575','#BDBDBD','#D02779'],
  Gold:     ['#F9A825','#FFD54F','#D02779'],
  Platinum: ['#7B1FA2','#CE93D8','#D02779'],
};

export default function ConfettiOverlay() {
  const { state } = useApp();
  const { showConfetti, tierUpgrade } = state;

  useEffect(() => {
    if (!showConfetti) return;
    const colors = TIER_COLORS[tierUpgrade?.newTier] || ['#D02779','#00897B','#F9A825'];
    const end = Date.now() + 2000;
    const frame = () => {
      confetti({
        particleCount: 4,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors,
      });
      confetti({
        particleCount: 4,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors,
      });
      if (Date.now() < end) requestAnimationFrame(frame);
    };
    frame();
  }, [showConfetti, tierUpgrade]);

  if (!showConfetti || !tierUpgrade) return null;

  return (
    <div className="confetti-overlay">
      <div className="tier-upgrade-badge">
        <h2>🎉 Tier Upgrade!</h2>
        <h1>{tierUpgrade.name}</h1>
        <p>is now <strong>{tierUpgrade.newTier}</strong></p>
      </div>
    </div>
  );
}
