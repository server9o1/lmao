import React from 'react';
import { useApp } from '../context/AppContext';
import { WHATSAPP_TEMPLATES } from '../mockData';

function fillTemplate(body, vars) {
  return body.replace(/\{\{(\w+)\}\}/g, (_, k) => vars[k] || `[${k}]`);
}

export default function PhoneMockup() {
  const { state, dispatch } = useApp();
  const { phoneMockup } = state;
  const visible = !!phoneMockup;

  const template = visible
    ? WHATSAPP_TEMPLATES.find(t => t.id === phoneMockup.template || t.name === phoneMockup.template)
    : null;

  const messageBody = template
    ? fillTemplate(template.body, { name: phoneMockup.memberName || 'Customer', ...phoneMockup.extra })
    : phoneMockup?.body || '';

  const recipientName = phoneMockup?.memberName || 'Customer';
  const now = new Date().toLocaleTimeString('en-US', { hour:'2-digit', minute:'2-digit' });

  return (
    <div className={`phone-overlay ${visible ? 'visible' : ''}`}>
      <div className="phone-frame">
        <div className="phone-notch" />
        <div className="phone-screen">
          <div className="wa-header">
            <div className="wa-avatar">
              {recipientName.charAt(0).toUpperCase()}
            </div>
            <div>
              <div className="wa-name">{recipientName}</div>
              <div className="wa-status">WhatsApp · online</div>
            </div>
          </div>
          <div className="wa-body">
            <div style={{ fontSize:11, color:'#999', textAlign:'center', marginBottom:8 }}>
              Today
            </div>
            <div className="wa-bubble">
              {messageBody}
            </div>
            <div className="wa-time">{now}</div>
            <div className="wa-sent">✓✓ Sent</div>
          </div>
        </div>
        <button
          className="phone-close-btn"
          onClick={() => dispatch({ type:'HIDE_PHONE_MOCKUP' })}
        >
          Tap to dismiss
        </button>
      </div>
    </div>
  );
}
