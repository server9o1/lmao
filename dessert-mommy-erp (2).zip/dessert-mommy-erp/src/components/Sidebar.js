import React from 'react';
import { useApp } from '../context/AppContext';

const NAV_ITEMS = [
  { id:'dashboard',     icon:'🏠', label:'Dashboard'        },
  { id:'orders',        icon:'🛒', label:'Order Entry'       },
  { id:'sweetpoints',   icon:'⭐', label:'Sweet Points'      },
  { id:'celebration',   icon:'🎉', label:'Celebration Hub'   },
  { id:'mysterybox',    icon:'🎁', label:'Mystery Box'        },
  { id:'members',       icon:'👥', label:'Members / CRM'     },
  { id:'walloffame',    icon:'📸', label:'Wall of Fame'       },
  { id:'financial',     icon:'📊', label:'Financial Dashboard'},
  { id:'staff',         icon:'🏷️', label:'Staff & Shifts'    },
  { id:'settings',      icon:'⚙️', label:'Settings / Branch' },
];

export default function Sidebar() {
  const { state, dispatch } = useApp();

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <h1>Dessert Mommy</h1>
        <div className="version">ERP Prototype v1.0</div>
        <div className="branch">
          <span>📍</span>
          <span>Kumarpara, Sylhet</span>
        </div>
      </div>

      <nav className="sidebar-nav">
        {NAV_ITEMS.map(item => (
          <div
            key={item.id}
            className={`nav-item ${state.activeModule === item.id ? 'active' : ''}`}
            onClick={() => dispatch({ type:'SET_MODULE', module:item.id })}
          >
            <span className="nav-icon">{item.icon}</span>
            <span>{item.label}</span>
          </div>
        ))}
      </nav>

      <div style={{ padding:'12px 16px', borderTop:'1px solid rgba(255,255,255,0.08)' }}>
        <div style={{ display:'flex', alignItems:'center', gap:8, cursor:'pointer' }}
          onClick={() => dispatch({ type:'SET_MODULE', module:'settings' })}>
          <div style={{
            width:32, height:32, borderRadius:'50%',
            background:'var(--pink)', display:'flex', alignItems:'center',
            justifyContent:'center', fontSize:14, fontWeight:700, color:'#fff'
          }}>S</div>
          <div>
            <div style={{ fontSize:13, fontWeight:600, color:'rgba(255,255,255,0.85)' }}>Sazidur Rahman</div>
            <div style={{ fontSize:11, color:'rgba(255,255,255,0.4)' }}>Founder & GM</div>
          </div>
        </div>
      </div>
    </aside>
  );
}
