import React, { useState } from 'react';
import { useApp } from '../context/AppContext';

const MODULE_TITLES = {
  dashboard:   '🏠 Dashboard',
  orders:      '🛒 Order Entry',
  sweetpoints: '⭐ Sweet Points Engine',
  celebration: '🎉 Celebration Hub',
  mysterybox:  '🎁 Mystery Box',
  members:     '👥 Members & CRM',
  walloffame:  '📸 Wall of Fame',
  financial:   '📊 Financial Dashboard',
  staff:       '🏷️ Staff & Shifts',
  settings:    '⚙️ Settings & Branch',
};

export default function TopBar() {
  const { state } = useApp();
  const [showFeed, setShowFeed] = useState(false);

  const todayOrders = state.orders.filter(o => {
    const today = new Date().toISOString().split('T')[0];
    return o.timestamp.startsWith(today);
  });

  const target = state.systemConfig.breakEvenOrders;
  const pct = Math.min(100, (todayOrders.length / target) * 100);

  const title = MODULE_TITLES[state.activeModule] || 'Dessert Mommy ERP';

  return (
    <header className="topbar">
      <div className="topbar-title">{title}</div>

      <div className="topbar-right">
        {/* Break-even mini tracker */}
        <div className="breakeven-bar-mini">
          <span className="label">Break-Even</span>
          <div className="track">
            <div className="fill" style={{ width:`${pct}%` }} />
          </div>
          <span className="count">{todayOrders.length}/{target}</span>
        </div>

        {/* Activity bell */}
        <div style={{ position:'relative' }}>
          <div className="bell-btn" onClick={() => setShowFeed(f => !f)}>
            🔔
            {state.activityFeed.length > 0 && (
              <span className="bell-badge">{Math.min(9, state.activityFeed.length)}</span>
            )}
          </div>

          {showFeed && (
            <>
              <div
                style={{ position:'fixed', inset:0, zIndex:199 }}
                onClick={() => setShowFeed(false)}
              />
              <div className="activity-dropdown" style={{ zIndex:200 }}>
                <div className="activity-dropdown-header">
                  Recent Activity
                </div>
                <div style={{ padding:'8px' }}>
                  {state.activityFeed.slice(0, 15).map(evt => (
                    <div key={evt.id} className="activity-item">
                      <div className="activity-dot" style={{ background:`${evt.color}20` }}>
                        {evt.icon}
                      </div>
                      <div>
                        <div className="activity-text">{evt.message}</div>
                        <div className="activity-time">
                          {new Date(evt.time).toLocaleTimeString('en-US', { hour:'2-digit', minute:'2-digit' })}
                        </div>
                      </div>
                    </div>
                  ))}
                  {state.activityFeed.length === 0 && (
                    <div className="empty-state" style={{ padding:'20px' }}>
                      <p>No activity yet</p>
                    </div>
                  )}
                </div>
              </div>
            </>
          )}
        </div>

        <div style={{
          background:'var(--pink-light)', borderRadius:8,
          padding:'6px 12px', fontSize:12, fontWeight:600, color:'var(--pink)'
        }}>
          🌐 Online
        </div>
      </div>
    </header>
  );
}
